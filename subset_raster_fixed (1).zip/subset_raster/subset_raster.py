# -*- coding: utf-8 -*-
"""
SubsetRaster QGIS plugin – rebuilt main module.
Original: Murat Çalışkan (caliskan.murat.20@gmail.com)
Additions: 9-point anchor dimension lock, pure-Python dialog.
"""
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon, QColor
from qgis.PyQt.QtWidgets import QAction, QFileDialog, QMessageBox

from .resources import *
from .subset_raster_dialog import SubsetRasterDialog
from .DrawRect import RectangleMapTool

import os
from pathlib import Path
from osgeo import ogr, gdal
from pyproj import CRS, Transformer
from shapely.wkt import loads
from shapely.ops import transform
from shapely.geometry import box
from datetime import date

from qgis.core import QgsProject, Qgis, QgsRasterLayer, QgsProcessingUtils


class SubsetRaster:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n',
                                   'SubsetRaster_{}.qm'.format(locale))
        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        self.actions = []
        self.menu = self.tr(u'&Subset Raster')
        self.first_start = None
        self.srs_wkt = ""

    def tr(self, message):
        return QCoreApplication.translate('SubsetRaster', message)

    def add_action(self, icon_path, text, callback, enabled_flag=True,
                   add_to_menu=True, add_to_toolbar=True,
                   status_tip=None, whats_this=None, parent=None):
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)
        if status_tip:
            action.setStatusTip(status_tip)
        if whats_this:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.iface.addToolBarIcon(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)
        self.actions.append(action)
        return action

    def initGui(self):
        icon_path = ':/plugins/subset_raster/icon.png'
        self.add_action(icon_path, text=self.tr(u'Subset Raster'),
                        callback=self.run, parent=self.iface.mainWindow())
        self.first_start = True

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&Subset Raster'), action)
            self.iface.removeToolBarIcon(action)

    # ── Extent sources ────────────────────────────────────────────────────

    def selectOutputFolder(self):
        self.dlg.le_outputFolder.setText("")
        output_dir = QFileDialog.getExistingDirectory(
            None, 'Select working directory', "", QFileDialog.ShowDirsOnly)
        self.dlg.le_outputFolder.setText(output_dir)

    def getDrawnCoor(self, map_canvas):
        self.srs_wkt = self.canvas.crs().toWkt()
        self.dlg.showMinimized()
        self.rect = RectangleMapTool(map_canvas, self.dlg)
        map_canvas.setMapTool(self.rect)
        self.checkCRS()

    def getCanvasExtent(self):
        self.srs_wkt = self.canvas.crs().toWkt()
        ext = self.iface.mapCanvas().extent()
        self.dlg.set_extent(ext.xMinimum(), ext.yMinimum(),
                            ext.xMaximum(), ext.yMaximum())
        self.checkCRS()

    def getLayerExtent(self):
        layerName = self.dlg.cb_layers.currentText()
        layers = QgsProject.instance().mapLayersByName(layerName)
        if layers:
            ext = layers[0].extent()
            self.srs_wkt = layers[0].crs().toWkt()
            self.dlg.set_extent(ext.xMinimum(), ext.yMinimum(),
                                ext.xMaximum(), ext.yMaximum())
        self.checkCRS()

    # ── Raster list ───────────────────────────────────────────────────────

    def getRasters(self):
        sender = self.dlg.sender()
        name = sender.objectName()

        if name == "pb_browse":
            existing = [Path(self.dlg.lw_input_ql.item(i).text()).resolve()
                        for i in range(self.dlg.lw_input_ql.count())]
            filePaths, _ = QFileDialog.getOpenFileNames(
                self.dlg, "Select Raster File(s)", "", 'All Files (*.*)')
            for fp in filePaths:
                if Path(fp).resolve() not in existing:
                    try:
                        if gdal.Open(fp):
                            self.dlg.lw_input_ql.addItem(fp)
                    except Exception:
                        pass

        elif name == "pb_getLayers":
            existing = [Path(self.dlg.lw_input_ql.item(i).text()).resolve()
                        for i in range(self.dlg.lw_input_ql.count())]
            for layer in QgsProject.instance().mapLayers().values():
                if layer.type() == 1:
                    src = layer.source()
                    if Path(src).resolve() not in existing:
                        try:
                            if gdal.Open(src):
                                self.dlg.lw_input_ql.addItem(src)
                        except Exception:
                            pass

        elif name == "pb_remove":
            for item in self.dlg.lw_input_ql.selectedItems():
                self.dlg.lw_input_ql.takeItem(self.dlg.lw_input_ql.row(item))

        elif name == "pb_clear":
            self.dlg.lw_input_ql.clear()

        self.dlg.label.setText(
            f"Raster List ({self.dlg.lw_input_ql.count()})")
        self.checkCRS()

    # ── CRS / compression ─────────────────────────────────────────────────

    def fillCompressWidget(self):
        self.dlg.cb_compressions.clear()
        if self.dlg.rb_vrt.isChecked():
            self.dlg.cb_compressions.addItem("NONE")
        elif self.dlg.rb_gtiff.isChecked():
            self.dlg.cb_compressions.addItems([
                "DEFLATE", "NONE", "LZW", "JPEG", "PACKBITS",
                "CCITTRLE", "CCITTFAX3", "CCITTFAX4", "LZMA", "ZSTD",
                "LERC", "LERC_DEFLATE", "LERC_ZSTD", "WEBP", "JXL"])
        elif self.dlg.rb_cog.isChecked():
            self.dlg.cb_compressions.addItems([
                "DEFLATE", "NONE", "LZW", "JPEG", "ZSTD",
                "WEBP", "LERC", "LERC_DEFLATE", "LERC_ZSTD", "LZMA"])

    def checkCRS(self):
        if not self.srs_wkt:
            return
        srs1 = CRS.from_wkt(self.srs_wkt)
        epsg = srs1.to_epsg()
        self.dlg.lbl_epsg.setText(
            f"EPSG : {epsg}" if epsg else "EPSG : Unknown")

        conflicts = 0
        for i in range(self.dlg.lw_input_ql.count()):
            it = self.dlg.lw_input_ql.item(i)
            ds = gdal.Open(it.text())
            if ds:
                srs2 = CRS.from_wkt(ds.GetSpatialRef().ExportToWkt())
                ds = None
                if not srs1.equals(srs2):
                    it.setForeground(QColor("red"))
                    conflicts += 1
                else:
                    it.setForeground(QColor("black"))
        self.dlg.label_2.setText(
            "Rasters with conflicting SRS are shown in red." if conflicts else "")

    def refreshEpsg(self, *args, **kwargs):
        old_wkt = self.srs_wkt
        self.srs_wkt = self.canvas.crs().toWkt()
        minX_ = self.dlg.sb_extent_minx.value()
        maxX_ = self.dlg.sb_extent_maxx.value()
        minY_ = self.dlg.sb_extent_miny.value()
        maxY_ = self.dlg.sb_extent_maxy.value()
        geom_wkt = box(minX_, minY_, maxX_, maxY_).wkt
        minX, maxX, minY, maxY = self._transform_geom(
            geom_wkt, old_wkt, self.srs_wkt)
        self.dlg.set_extent(minX, minY, maxX, maxY)
        self.checkCRS()

    def _transform_geom(self, geom_wkt, src_wkt, dst_wkt):
        geom = loads(geom_wkt)
        from_crs = CRS.from_wkt(src_wkt)
        to_crs = CRS.from_wkt(dst_wkt)
        xformer = Transformer.from_crs(from_crs, to_crs, always_xy=True)
        projected = transform(xformer.transform, geom)
        ogr_geom = ogr.CreateGeometryFromWkt(projected.wkt)
        return ogr_geom.GetEnvelope()   # (minX, maxX, minY, maxY)

    # ── Raster output ─────────────────────────────────────────────────────

    def _gen_name(self, folder, stem, ext):
        base = stem + "_clipped"
        candidate = base
        n = 2
        while os.path.isfile(os.path.join(folder, f"{candidate}.{ext}")):
            candidate = f"{base}_{n}"
            n += 1
        return f"{candidate}.{ext}"

    def subsetRaster(self, input_path, out_folder, name, opts,
                     minX_, minY_, maxX_, maxY_):
        srs1 = CRS.from_wkt(self.srs_wkt)
        ds = gdal.Open(input_path)
        srs2_wkt = ds.GetSpatialRef().ExportToWkt()
        srs2 = CRS.from_wkt(srs2_wkt)
        ds = None

        if not srs1.equals(srs2):
            geom_wkt = box(minX_, minY_, maxX_, maxY_).wkt
            minX, maxX, minY, maxY = self._transform_geom(
                geom_wkt, self.srs_wkt, srs2_wkt)
        else:
            minX, minY, maxX, maxY = minX_, minY_, maxX_, maxY_

        add_alpha = self.dlg.chc_addAlpha.isChecked()

        if self.dlg.rb_gtiff.isChecked():
            out_name = self._gen_name(out_folder, name, "tif")
            out_path = os.path.join(out_folder, out_name)
            gdal.Warp(out_path, input_path,
                      outputBounds=(minX, minY, maxX, maxY),
                      format="GTiff", creationOptions=opts,
                      dstAlpha=add_alpha)
        elif self.dlg.rb_cog.isChecked():
            out_name = self._gen_name(out_folder, name, "tif")
            out_path = os.path.join(out_folder, out_name)
            gdal.Warp(out_path, input_path,
                      outputBounds=(minX, minY, maxX, maxY),
                      format="COG", creationOptions=opts,
                      dstAlpha=add_alpha)
        else:  # VRT
            out_name = self._gen_name(out_folder, name, "vrt")
            out_path = os.path.join(out_folder, out_name)
            gdal.BuildVRT(out_path, input_path,
                          outputBounds=(minX, minY, maxX, maxY),
                          addAlpha=add_alpha)

        if self.dlg.chb_addToMap.isChecked():
            layer = QgsRasterLayer(out_path, out_name, "gdal")
            QgsProject.instance().addMapLayer(layer)

    def executeSubset(self):
        ql_count = self.dlg.lw_input_ql.count()
        if ql_count == 0:
            QMessageBox.critical(None, "ERROR", "No raster in raster list!")
            return

        folder_text = self.dlg.le_outputFolder.text().strip()
        out_folder = folder_text if folder_text else QgsProcessingUtils.tempFolder()
        if not os.path.isdir(out_folder):
            QMessageBox.critical(None, "ERROR", "Invalid folder path")
            return

        minX_ = self.dlg.sb_extent_minx.value()
        maxX_ = self.dlg.sb_extent_maxx.value()
        minY_ = self.dlg.sb_extent_miny.value()
        maxY_ = self.dlg.sb_extent_maxy.value()

        compress = self.dlg.cb_compressions.currentText()
        compress = None if compress == "NONE" else compress
        extra = [i.strip() for i in self.dlg.le_options.text().split(",")
                 if i.strip() and not i.strip().lower().startswith("compress")]
        opts = ([f"COMPRESS={compress}"] if compress else []) + extra

        self.dlg.setEnabled(False)
        self.dlg.pushButton.setText("RUNNING…")

        try:
            for i in range(ql_count):
                rp = self.dlg.lw_input_ql.item(i).text()
                stem = os.path.split(rp)[-1].rsplit(".", 1)[0]
                self.subsetRaster(rp, out_folder, stem, opts,
                                  minX_, minY_, maxX_, maxY_)
            self.iface.messageBar().pushMessage(
                "Success", "Subset(s) created!", level=Qgis.Success, duration=5)
        except Exception as exc:
            QMessageBox.critical(None, "ERROR", str(exc))
        finally:
            self.dlg.setEnabled(True)
            self.dlg.pushButton.setText("RUN")

    # ── Plugin run ────────────────────────────────────────────────────────

    def run(self):
        if self.first_start:
            self.dlg = SubsetRasterDialog()

            icon = 'mka.png' if any([
                (date.today().day == 18 and date.today().month == 3),
                (date.today().day == 23 and date.today().month == 4),
                (date.today().day == 19 and date.today().month == 5),
                (date.today().day == 30 and date.today().month == 8),
                (date.today().day == 29 and date.today().month == 10),
                (date.today().day == 10 and date.today().month == 11),
            ]) else 'icon.png'
            self.dlg.setWindowIcon(QIcon(f':/plugins/subset_raster/{icon}'))

            self.dlg.lbl_info.setText(
                '<html><head/><body><a href="https://github.com/caliskanmurat'
                '/qgis_subset_raster_plugin"><img width="20" height="20" '
                'src=":/plugins/subset_raster/info.svg"/></a></body></html>')

            self.canvas = QgsProject.instance()
            self.srs_wkt = self.canvas.crs().toWkt()

            # Populate layers combo
            all_layers = [v.name() for v in
                          QgsProject.instance().mapLayers().values()]
            self.dlg.cb_layers.clear()
            self.dlg.cb_layers.addItems(all_layers)

            # Auto-populate raster list from project
            self.dlg.lw_input_ql.clear()
            for layer in QgsProject.instance().mapLayers().values():
                if layer.type() == 1:
                    src = layer.source()
                    try:
                        if gdal.Open(src):
                            self.dlg.lw_input_ql.addItem(src)
                    except Exception:
                        pass
            self.dlg.label.setText(
                f"Raster List ({self.dlg.lw_input_ql.count()})")

            self.fillCompressWidget()
            self.checkCRS()

            # Assign objectNames so getRasters() can identify callers
            self.dlg.pb_browse.setObjectName("pb_browse")
            self.dlg.pb_getLayers.setObjectName("pb_getLayers")
            self.dlg.pb_remove.setObjectName("pb_remove")
            self.dlg.pb_clear.setObjectName("pb_clear")

            # Connect signals
            self.dlg.btn_canvasExtent.clicked.connect(self.getCanvasExtent)
            self.dlg.btn_layerextent.clicked.connect(self.getLayerExtent)
            self.dlg.tbtn_draw.clicked.connect(
                lambda: self.getDrawnCoor(self.iface.mapCanvas()))
            self.dlg.rb_vrt.toggled.connect(self.fillCompressWidget)
            self.dlg.rb_gtiff.toggled.connect(self.fillCompressWidget)
            self.dlg.rb_cog.toggled.connect(self.fillCompressWidget)
            self.dlg.pushButton.clicked.connect(self.executeSubset)
            self.dlg.tb_browse.clicked.connect(self.selectOutputFolder)
            self.dlg.pb_browse.clicked.connect(self.getRasters)
            self.dlg.pb_getLayers.clicked.connect(self.getRasters)
            self.dlg.pb_remove.clicked.connect(self.getRasters)
            self.dlg.pb_clear.clicked.connect(self.getRasters)
            self.dlg.lbl_refresh.mousePressEvent = self.refreshEpsg

            self.first_start = False

        self.dlg.show()
        self.dlg.raise_()

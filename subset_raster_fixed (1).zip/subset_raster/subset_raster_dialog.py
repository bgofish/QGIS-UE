# -*- coding: utf-8 -*-
"""
SubsetRasterDialog - pure-Python rebuild (no .ui file dependency).
Adds:
  - Width / Height dimension fields (in CRS units)
  - 9-point anchor lock: Centre, LL, UL, LR, UR, Mid-L, Mid-R, Mid-Top, Mid-Bottom
  - "Lock dimensions" checkbox: when ON, changing W/H or anchor recalculates
    the extent spinboxes rather than the other way around.
"""
import os
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox,
    QLabel, QLineEdit, QComboBox, QPushButton, QCheckBox,
    QRadioButton, QButtonGroup, QDoubleSpinBox, QListWidget,
    QAbstractItemView, QToolButton, QSizePolicy, QWidget, QFrame,
    QSplitter,
)
from qgis.PyQt.QtCore import Qt, QSize
from qgis.PyQt.QtGui import QColor, QIcon


# ── 9-point anchor helpers ──────────────────────────────────────────────────

ANCHORS = [
    "Centre",
    "Lower Left",  "Mid Bottom",  "Lower Right",
    "Mid Left",                   "Mid Right",
    "Upper Left",  "Mid Top",     "Upper Right",
]

def anchor_point(minX, minY, maxX, maxY, anchor):
    """Extract the anchor (x, y) from a bounding box."""
    cx = (minX + maxX) / 2.0
    cy = (minY + maxY) / 2.0
    return {
        "Centre":      (cx,   cy),
        "Lower Left":  (minX, minY),
        "Mid Bottom":  (cx,   minY),
        "Lower Right": (maxX, minY),
        "Mid Left":    (minX, cy),
        "Mid Right":   (maxX, cy),
        "Upper Left":  (minX, maxY),
        "Mid Top":     (cx,   maxY),
        "Upper Right": (maxX, maxY),
    }[anchor]


def bbox_from_anchor(ax, ay, w, h, anchor):
    """Compute (minX, minY, maxX, maxY) given anchor point, width, height."""
    dx = {
        "Centre":      (-w / 2, w / 2),
        "Lower Left":  (0,      w),
        "Mid Bottom":  (-w / 2, w / 2),
        "Lower Right": (-w,     0),
        "Mid Left":    (0,      w),
        "Mid Right":   (-w,     0),
        "Upper Left":  (0,      w),
        "Mid Top":     (-w / 2, w / 2),
        "Upper Right": (-w,     0),
    }[anchor]
    dy = {
        "Centre":      (-h / 2, h / 2),
        "Lower Left":  (0,      h),
        "Mid Bottom":  (0,      h),
        "Lower Right": (0,      h),
        "Mid Left":    (-h / 2, h / 2),
        "Mid Right":   (-h / 2, h / 2),
        "Upper Left":  (-h,     0),
        "Mid Top":     (-h,     0),
        "Upper Right": (-h,     0),
    }[anchor]
    return ax + dx[0], ay + dy[0], ax + dx[1], ay + dy[1]


# ── 3x3 anchor grid button widget ──────────────────────────────────────────

class AnchorGrid(QWidget):
    """A 3×3 grid of toggle buttons visualising the 9 anchor points.
    Selecting one emits the anchor name via a simple callback.
    Layout (row, col):
        UL    Mid-Top    UR
        Mid-L  Centre  Mid-R
        LL   Mid-Bot    LR
    """
    _LAYOUT = [
        ["Upper Left",  "Mid Top",    "Upper Right"],
        ["Mid Left",    "Centre",     "Mid Right"],
        ["Lower Left",  "Mid Bottom", "Lower Right"],
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self._buttons = {}
        self._selected = "Centre"
        self._callback = None

        grid = __import__("qgis.PyQt.QtWidgets", fromlist=["QGridLayout"]).QGridLayout()
        grid.setSpacing(2)
        grid.setContentsMargins(0, 0, 0, 0)

        for r, row in enumerate(self._LAYOUT):
            for c, name in enumerate(row):
                btn = QPushButton()
                btn.setFixedSize(28, 28)
                btn.setCheckable(True)
                btn.setToolTip(name)
                btn.clicked.connect(lambda checked, n=name: self._select(n))
                self._buttons[name] = btn
                grid.addWidget(btn, r, c)

        self.setLayout(grid)
        self._select("Centre")

    def _select(self, name):
        for n, b in self._buttons.items():
            b.setChecked(n == name)
        self._selected = name
        if self._callback:
            self._callback(name)

    def current(self):
        return self._selected

    def set_callback(self, fn):
        self._callback = fn

    def set_anchor(self, name):
        if name in self._buttons:
            self._select(name)


# ── Main Dialog ─────────────────────────────────────────────────────────────

class SubsetRasterDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Subset Raster")
        self.setMinimumWidth(640)
        self._suppress_signals = False
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setSpacing(6)

        # ── Input rasters ───────────────────────────────────────────────
        in_group = QGroupBox("Input Rasters")
        in_v = QVBoxLayout(in_group)

        self.label = QLabel("Raster List (0)")
        in_v.addWidget(self.label)

        self.lw_input_ql = QListWidget()
        self.lw_input_ql.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.lw_input_ql.setMinimumHeight(80)
        in_v.addWidget(self.lw_input_ql)

        btn_row = QHBoxLayout()
        self.pb_browse    = QPushButton("Browse…")
        self.pb_getLayers = QPushButton("From Layers")
        self.pb_remove    = QPushButton("Remove")
        self.pb_clear     = QPushButton("Clear")
        for b in (self.pb_browse, self.pb_getLayers, self.pb_remove, self.pb_clear):
            btn_row.addWidget(b)
        in_v.addLayout(btn_row)

        self.label_2 = QLabel("")
        self.label_2.setStyleSheet("color: red; font-size: 10px;")
        in_v.addWidget(self.label_2)
        root.addWidget(in_group)

        # ── Extent ──────────────────────────────────────────────────────
        ext_group = QGroupBox("Extent")
        ext_v = QVBoxLayout(ext_group)

        # Coordinates grid
        coord_form = QFormLayout()
        self.sb_extent_maxy = self._dspin(label="North (Y max):")
        coord_form.addRow("North (Y max):", self.sb_extent_maxy)
        xrow = QHBoxLayout()
        self.sb_extent_minx = self._dspin()
        self.sb_extent_maxx = self._dspin()
        xrow.addWidget(QLabel("West (X min):"))
        xrow.addWidget(self.sb_extent_minx)
        xrow.addStretch()
        xrow.addWidget(QLabel("East (X max):"))
        xrow.addWidget(self.sb_extent_maxx)
        coord_form.addRow(xrow)
        self.sb_extent_miny = self._dspin(label="South (Y min):")
        coord_form.addRow("South (Y min):", self.sb_extent_miny)
        ext_v.addLayout(coord_form)

        # Extent source buttons + CRS
        src_row = QHBoxLayout()
        self.cb_layers = QComboBox()
        self.cb_layers.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        src_row.addWidget(self.cb_layers)
        self.btn_layerextent  = QPushButton("Layer Extent")
        self.btn_canvasExtent = QPushButton("Canvas Extent")
        self.tbtn_draw        = QToolButton()
        self.tbtn_draw.setText("✏ Draw")
        self.tbtn_draw.setToolTip("Draw extent on map canvas")
        for b in (self.btn_layerextent, self.btn_canvasExtent, self.tbtn_draw):
            src_row.addWidget(b)
        ext_v.addLayout(src_row)

        epsg_row = QHBoxLayout()
        self.lbl_epsg    = QLabel("EPSG : Unknown")
        self.lbl_refresh = QLabel("🔄")
        self.lbl_refresh.setToolTip("Re-project coordinates to current project CRS")
        self.lbl_refresh.setCursor(Qt.PointingHandCursor)
        self.lbl_info    = QLabel()
        epsg_row.addWidget(self.lbl_epsg)
        epsg_row.addWidget(self.lbl_refresh)
        epsg_row.addStretch()
        epsg_row.addWidget(self.lbl_info)
        ext_v.addLayout(epsg_row)
        root.addWidget(ext_group)

        # ── Dimensions + Anchor ─────────────────────────────────────────
        dim_group = QGroupBox("Dimensions && Anchor")
        dim_outer = QHBoxLayout(dim_group)

        # Left: W/H spinboxes + lock checkbox
        dim_form = QFormLayout()
        self.sb_width  = self._dspin(dmin=0, dmax=1e9, decimals=4)
        self.sb_height = self._dspin(dmin=0, dmax=1e9, decimals=4)
        dim_form.addRow("Width (CRS units):",  self.sb_width)
        dim_form.addRow("Height (CRS units):", self.sb_height)
        self.chk_lock = QCheckBox("Lock – recalculate extent from anchor when W/H change")
        self.chk_lock.setChecked(True)
        dim_form.addRow(self.chk_lock)
        dim_note = QLabel("When unlocked, W/H update from the drawn extent.\nWhen locked, changing W/H or anchor recalculates the extent.")
        dim_note.setWordWrap(True)
        dim_note.setStyleSheet("color: gray; font-size: 10px;")
        dim_form.addRow(dim_note)
        dim_outer.addLayout(dim_form, stretch=2)

        # Separator
        sep = QFrame()
        sep.setFrameShape(QFrame.VLine)
        sep.setFrameShadow(QFrame.Sunken)
        dim_outer.addWidget(sep)

        # Right: 3×3 anchor grid
        anchor_v = QVBoxLayout()
        anchor_v.addWidget(QLabel("Anchor point:"))
        self.anchor_grid = AnchorGrid()
        self.anchor_grid.set_callback(self._on_anchor_changed)
        anchor_v.addWidget(self.anchor_grid)
        self.anchor_label = QLabel("Centre")
        self.anchor_label.setAlignment(Qt.AlignCenter)
        self.anchor_label.setStyleSheet("font-weight: bold; font-size: 10px;")
        anchor_v.addWidget(self.anchor_label)
        anchor_v.addStretch()
        dim_outer.addLayout(anchor_v, stretch=1)

        root.addWidget(dim_group)

        # Wire up W/H signals – track which dimension the user edited
        self.sb_width.valueChanged.connect(self._on_width_changed)
        self.sb_height.valueChanged.connect(self._on_height_changed)
        for sb in (self.sb_extent_minx, self.sb_extent_miny,
                   self.sb_extent_maxx, self.sb_extent_maxy):
            sb.valueChanged.connect(self._on_extent_changed)

        # ── Output type ──────────────────────────────────────────────────
        out_group = QGroupBox("Output Type")
        out_h = QHBoxLayout(out_group)
        self.rb_vrt   = QRadioButton("GDAL Virtual Format (.vrt)")
        self.rb_gtiff = QRadioButton("GeoTIFF (.tif)")
        self.rb_cog   = QRadioButton("COG")
        self.rb_vrt.setChecked(True)
        self._out_bg = QButtonGroup(self)
        for rb in (self.rb_vrt, self.rb_gtiff, self.rb_cog):
            self._out_bg.addButton(rb)
            out_h.addWidget(rb)
        out_h.addWidget(QLabel("COMPRESS:"))
        self.cb_compressions = QComboBox()
        out_h.addWidget(self.cb_compressions)
        root.addWidget(out_group)

        # Extra creation options
        extra_group = QGroupBox("Extra Creation Options (Optional)")
        extra_v = QVBoxLayout(extra_group)
        self.le_options = QLineEdit()
        self.le_options.setPlaceholderText("e.g. TFW=YES, BIGTIFF=YES, PREDICTOR=2")
        extra_v.addWidget(self.le_options)
        root.addWidget(extra_group)

        # Output folder
        out_folder_group = QGroupBox("Output Folder Path")
        out_folder_v = QVBoxLayout(out_folder_group)
        folder_row = QHBoxLayout()
        self.le_outputFolder = QLineEdit()
        self.le_outputFolder.setPlaceholderText("[Create temporary layer]")
        self.tb_browse = QToolButton()
        self.tb_browse.setText("…")
        folder_row.addWidget(self.le_outputFolder)
        folder_row.addWidget(self.tb_browse)
        out_folder_v.addLayout(folder_row)
        root.addWidget(out_folder_group)

        # Bottom row
        bot_row = QHBoxLayout()
        self.chb_addToMap  = QCheckBox("Add results to map")
        self.chb_addToMap.setChecked(True)
        self.chc_addAlpha  = QCheckBox("Add alpha band")
        self.pushButton    = QPushButton("RUN")
        self.pushButton.setMinimumHeight(36)
        font = self.pushButton.font()
        font.setBold(True)
        self.pushButton.setFont(font)
        bot_row.addWidget(self.chb_addToMap)
        bot_row.addWidget(self.chc_addAlpha)
        bot_row.addStretch()
        bot_row.addWidget(self.pushButton)
        root.addLayout(bot_row)

    # ── Helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def _dspin(dmin=-1e12, dmax=1e12, decimals=8, label=None):
        sb = QDoubleSpinBox()
        sb.setRange(dmin, dmax)
        sb.setDecimals(decimals)
        sb.setValue(0.0)
        sb.setMinimumWidth(160)
        return sb

    # ── Anchor/dimension slot logic ───────────────────────────────────────

    def _on_anchor_changed(self, name):
        self.anchor_label.setText(name)
        if self.chk_lock.isChecked():
            self._apply_wh_to_extent()

    def _on_width_changed(self):
        if self._suppress_signals:
            return
        if self.chk_lock.isChecked():
            self._apply_wh_to_extent()

    def _on_height_changed(self):
        if self._suppress_signals:
            return
        if self.chk_lock.isChecked():
            self._apply_wh_to_extent()

    def _on_wh_changed(self):
        """Kept for backward compatibility."""
        if self._suppress_signals:
            return
        if self.chk_lock.isChecked():
            self._apply_wh_to_extent()

    def _on_extent_changed(self):
        """When the extent spinboxes change while NOT locked, sync W/H."""
        if self._suppress_signals:
            return
        if not self.chk_lock.isChecked():
            self._sync_wh_from_extent()

    def _sync_wh_from_extent(self):
        """Read the 4 spinboxes and update W/H to match."""
        minX = self.sb_extent_minx.value()
        maxX = self.sb_extent_maxx.value()
        minY = self.sb_extent_miny.value()
        maxY = self.sb_extent_maxy.value()
        w = abs(maxX - minX)
        h = abs(maxY - minY)
        self._suppress_signals = True
        self.sb_width.setValue(w)
        self.sb_height.setValue(h)
        self._suppress_signals = False

    def _apply_wh_to_extent(self):
        """Recompute the 4 extent spinboxes from anchor + W/H."""
        w = self.sb_width.value()
        h = self.sb_height.value()
        if w <= 0 or h <= 0:
            return
        minX = self.sb_extent_minx.value()
        maxX = self.sb_extent_maxx.value()
        minY = self.sb_extent_miny.value()
        maxY = self.sb_extent_maxy.value()
        anchor = self.anchor_grid.current()
        ax, ay = anchor_point(minX, minY, maxX, maxY, anchor)
        new_minX, new_minY, new_maxX, new_maxY = bbox_from_anchor(ax, ay, w, h, anchor)
        self._suppress_signals = True
        self.sb_extent_minx.setValue(new_minX)
        self.sb_extent_miny.setValue(new_minY)
        self.sb_extent_maxx.setValue(new_maxX)
        self.sb_extent_maxy.setValue(new_maxY)
        self._suppress_signals = False

    def set_extent(self, minX, minY, maxX, maxY):
        """Called from the main plugin to set extent (canvas, layer, draw).
        When unlocked: syncs W/H from the new extent.
        When locked with valid W/H: keeps W/H, recomputes extent from anchor + W/H.
        When locked but W/H are 0 (uninitialised): seeds W/H from the drawn extent."""
        self._suppress_signals = True
        self.sb_extent_minx.setValue(minX)
        self.sb_extent_miny.setValue(minY)
        self.sb_extent_maxx.setValue(maxX)
        self.sb_extent_maxy.setValue(maxY)
        self._suppress_signals = False
        if self.chk_lock.isChecked() and (self.sb_width.value() > 0 or self.sb_height.value() > 0):
            self._apply_wh_to_extent()
        else:
            self._sync_wh_from_extent()

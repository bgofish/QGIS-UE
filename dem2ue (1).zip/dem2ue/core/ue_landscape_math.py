# -*- coding: utf-8 -*-
"""
Pure math for converting DEM elevation data into Unreal Engine Landscape
heightmap encoding. Deliberately has zero dependency on GDAL/numpy-heavy
raster IO or QGIS APIs so it can be exercised by plain unit tests.

References (Epic Developer Community documentation, "Landscape Technical
Guide in Unreal Engine"):

  * A Landscape heightmap value is an unsigned 16-bit integer. The engine
    interprets that value as a normalized height in the range
    [-256.0, 255.992...] (i.e. value 32768 == 0.0, full range spans 512.0
    units), then multiplies by the "Z Scale" entered at import time to get
    the actor-local height in centimeters (Unreal's base unit is 1 cm).

        local_height_cm = (raw_uint16 - 32768) / 128.0 * z_scale

  * Likewise the X/Y "Scale" entered at import is a direct cm-per-vertex
    spacing multiplier: scale value 100 == 100 cm == 1 m per vertex.

  * Valid heightmap resolutions are constrained to (components * quads_per_
    component + 1) in each direction. Epic's "Recommended Landscape Sizes"
    table (consistently reproduced across the 4.27/5.x technical guide and
    third-party guides) gives the standard square sizes used in practice:
    127, 253, 505, 1009, 2017, 4033, 8129.
"""

from __future__ import annotations

import math
from typing import List, Tuple, Dict, Optional

# Epic's standard "Recommended Landscape Size" vertex counts (square).
# Derived from (components * 63 quads/component + 1) at 1 section/component,
# i.e. 2,4,8,16,32,64,128 components per side.
STANDARD_SIZES: List[int] = [127, 253, 505, 1009, 2017, 4033, 8129]

# Unreal's height-encoding constants (see module docstring).
HEIGHT_MIDPOINT = 32768  # raw uint16 value representing local height 0
HEIGHT_RATIO = 1.0 / 128.0  # local-height-units per raw uint16 step
HEIGHT_FULL_RANGE_UNITS = 512.0  # total span covered by 0..65535
UU_PER_CM = 1.0  # Unreal base unit is 1 cm


def nearest_valid_size(n: int, mode: str = "nearest") -> int:
    """Snap an arbitrary pixel dimension to the nearest entry in
    STANDARD_SIZES.

    mode: 'nearest', 'floor' (largest valid size <= n), or 'ceil'
    (smallest valid size >= n).
    """
    if n <= STANDARD_SIZES[0]:
        return STANDARD_SIZES[0]
    if n >= STANDARD_SIZES[-1]:
        return STANDARD_SIZES[-1]
    if mode == "floor":
        candidates = [s for s in STANDARD_SIZES if s <= n]
        return candidates[-1]
    if mode == "ceil":
        candidates = [s for s in STANDARD_SIZES if s >= n]
        return candidates[0]
    # nearest
    return min(STANDARD_SIZES, key=lambda s: abs(s - n))


def valid_sizes() -> List[int]:
    return list(STANDARD_SIZES)


def compute_encoding(
    elev_min: float,
    elev_max: float,
    vertical_exaggeration: float = 1.0,
) -> Dict[str, float]:
    """Given the real-world elevation range (in meters) that will be
    stretched across the full 0..65535 uint16 range, compute the Unreal
    import settings needed to reproduce true (or exaggerated) real-world
    relief.

    Returns a dict with:
      z_scale            -> value to type into the Landscape import dialog's
                             Z Scale field
      actor_z_offset_m    -> recommended world-Z (in meters) to place the
                             Landscape actor at, so that the *encoded*
                             midpoint (raw value 32768) lands at the correct
                             absolute elevation
      actor_z_offset_cm   -> same, in centimeters (Unreal's native unit)
      height_range_m      -> elev_max - elev_min, post-exaggeration
    """
    if elev_max <= elev_min:
        raise ValueError("elev_max must be greater than elev_min")

    height_range_m = (elev_max - elev_min) * vertical_exaggeration

    # Full 16-bit span maps to HEIGHT_FULL_RANGE_UNITS local-height-units,
    # which get multiplied by z_scale to become centimeters. We want that
    # product, converted to meters, to equal height_range_m.
    #   height_range_m * 100 (cm) == HEIGHT_FULL_RANGE_UNITS * z_scale
    z_scale = (height_range_m * 100.0) / HEIGHT_FULL_RANGE_UNITS

    # Raw value 32768 sits at the midpoint of the 0..65535 stretch, i.e. at
    # elevation (elev_min + elev_max) / 2 in the original (non-exaggerated)
    # data. Place the actor there so absolute elevations line up.
    midpoint_elev_m = (elev_min + elev_max) / 2.0
    actor_z_offset_cm = midpoint_elev_m * vertical_exaggeration * 100.0

    return {
        "z_scale": z_scale,
        "actor_z_offset_m": actor_z_offset_cm / 100.0,
        "actor_z_offset_cm": actor_z_offset_cm,
        "height_range_m": height_range_m,
    }


def compute_xy_scale(pixel_size_m: float) -> float:
    """Unreal's X/Y Scale field is a direct cm-per-vertex multiplier
    (scale=100 -> 1 m/vertex). Convert a DEM pixel spacing in meters into
    the value to type into that field."""
    return pixel_size_m * 100.0


def elevation_to_uint16_params(elev_min: float, elev_max: float) -> Tuple[float, float]:
    """Returns (scale, offset) such that uint16_value = round(elev*scale +
    offset), clipped to [0, 65535]."""
    if elev_max <= elev_min:
        raise ValueError("elev_max must be greater than elev_min")
    scale = 65535.0 / (elev_max - elev_min)
    offset = -elev_min * scale
    return scale, offset


def auto_utm_epsg(lon: float, lat: float) -> int:
    """Pure-formula UTM zone -> EPSG code, no pyproj dependency.
    WGS84 / UTM north zones are EPSG:326xx, south zones EPSG:327xx."""
    zone = int(math.floor((lon + 180.0) / 6.0) + 1)
    zone = max(1, min(60, zone))
    if lat >= 0:
        return 32600 + zone
    return 32700 + zone


def compute_tile_grid(
    width: int,
    height: int,
    tile_w: int,
    tile_h: int,
    overlap: int = 1,
) -> List[Dict[str, int]]:
    """Split a width x height raster into a grid of tiles, each tile_w x
    tile_h, sharing `overlap` pixels of border with their neighbors so
    adjacent Landscape Streaming Proxies line up seamlessly.

    Returns a list of dicts: {col, row, x_off, y_off, w, h} in source-pixel
    coordinates. The grid always covers the full source extent; the last
    column/row may be clipped to the source bounds (caller should pad if an
    exact tile_w/tile_h is required by Unreal).
    """
    if tile_w <= overlap or tile_h <= overlap:
        raise ValueError("tile size must be larger than the overlap")

    stride_x = tile_w - overlap
    stride_y = tile_h - overlap

    n_cols = max(1, math.ceil((width - overlap) / stride_x))
    n_rows = max(1, math.ceil((height - overlap) / stride_y))

    tiles = []
    for row in range(n_rows):
        for col in range(n_cols):
            x_off = col * stride_x
            y_off = row * stride_y
            w = min(tile_w, width - x_off)
            h = min(tile_h, height - y_off)
            tiles.append(
                {
                    "col": col,
                    "row": row,
                    "x_off": x_off,
                    "y_off": y_off,
                    "w": w,
                    "h": h,
                }
            )
    return tiles


def compute_padded_canvas_size(
    width: int,
    height: int,
    tile_w: int,
    tile_h: int,
    overlap: int = 1,
) -> Dict[str, int]:
    """Compute the canvas size that the source DEM must be edge-padded to
    so that every tile produced by compute_tile_grid is exactly tile_w x
    tile_h (no clipped partial tiles at the right/bottom edge, which would
    not be a valid Unreal Landscape resolution).
    """
    if tile_w <= overlap or tile_h <= overlap:
        raise ValueError("tile size must be larger than the overlap")
    stride_x = tile_w - overlap
    stride_y = tile_h - overlap
    n_cols = max(1, math.ceil((width - overlap) / stride_x))
    n_rows = max(1, math.ceil((height - overlap) / stride_y))
    padded_w = (n_cols - 1) * stride_x + tile_w
    padded_h = (n_rows - 1) * stride_y + tile_h
    return {
        "n_cols": n_cols,
        "n_rows": n_rows,
        "padded_w": padded_w,
        "padded_h": padded_h,
        "stride_x": stride_x,
        "stride_y": stride_y,
    }


def tile_world_offset_m(
    tile: Dict[str, int],
    stride_x_px: int,
    stride_y_px: int,
    pixel_size_m: float,
) -> Tuple[float, float]:
    """World-space (X, Y) offset in meters at which to place a tile's
    Landscape Streaming Proxy actor, relative to the origin tile (col=0,
    row=0), accounting for the shared-border overlap stride."""
    x_m = tile["col"] * stride_x_px * pixel_size_m
    y_m = tile["row"] * stride_y_px * pixel_size_m
    return x_m, y_m

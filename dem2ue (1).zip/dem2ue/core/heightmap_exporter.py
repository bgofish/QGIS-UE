# -*- coding: utf-8 -*-
"""
High-level orchestration: DEM file -> Unreal-ready heightmap(s) + manifest.

This is the single entry point used by both the dock widget UI
(dem2ue_dockwidget.py) and the Processing algorithm
(processing/export_heightmap_algorithm.py), so the two front-ends can never
drift out of sync on behavior.
"""

from __future__ import annotations

import json
import os
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np

from . import raster_io
from .ue_landscape_math import (
    STANDARD_SIZES,
    nearest_valid_size,
    compute_encoding,
    compute_xy_scale,
    compute_padded_canvas_size,
    compute_tile_grid,
    tile_world_offset_m,
)

ProgressCB = Optional[Callable[[float, str], None]]


def _report(cb: ProgressCB, frac: float, msg: str) -> None:
    if cb:
        cb(frac, msg)


def _resolve_output_raster(
    dem_path: str,
    src_info,
    resolved_epsg: int,
    resolution_mode: str,
    custom_width: Optional[int],
    custom_height: Optional[int],
    resample_alg: str,
    crop_mode: str,
    crop_extent: Optional[Tuple[float, float, float, float]],
    square_strategy: str,
    progress_cb: ProgressCB,
):
    """Handles every combination of resolution_mode x crop_mode and
    returns the final warped in-memory gdal.Dataset, plus a crop_info dict
    describing what was actually done (for the manifest).

    Key invariant: resolution_mode='snap' ALWAYS produces a square output.
    By default (square_strategy='crop') that's achieved by cropping the
    longer axis down to match the shorter one at native resolution before
    snapping - never by anisotropically stretching one axis more than the
    other, which would distort real-world slopes/terrain shape.
    """
    crop_info: Dict = {"crop_mode": crop_mode, "square_strategy": square_strategy, "applied_bounds_target_crs": None}

    initial_bounds = None
    if crop_mode == "extent":
        if crop_extent is None:
            raise ValueError("crop_extent is required when crop_mode='extent'")
        initial_bounds = raster_io.transform_bounds_to_crs(crop_extent, src_info.wkt, resolved_epsg)

    if resolution_mode == "custom":
        if not custom_width or not custom_height:
            raise ValueError("custom_width/custom_height required for resolution_mode='custom'")
        if crop_mode == "centered_square":
            _report(progress_cb, 0.08, "Measuring native extent for centered-square crop...")
            native_ds = raster_io.warp_dem(dem_path, resolved_epsg, resample_alg=resample_alg, output_bounds=initial_bounds)
            bounds, px_x, px_y = raster_io.get_bounds_and_pixel_size(native_ds)
            sq_bounds, _ = raster_io.centered_square_bounds(bounds, native_ds.RasterXSize, native_ds.RasterYSize, px_x, px_y)
            native_ds = None
            crop_info["applied_bounds_target_crs"] = sq_bounds
            _report(progress_cb, 0.15, "Warping cropped square region to custom size {}x{}...".format(custom_width, custom_height))
            ds = raster_io.warp_dem(dem_path, resolved_epsg, target_width=custom_width, target_height=custom_height,
                                     resample_alg=resample_alg, output_bounds=sq_bounds)
        else:
            crop_info["applied_bounds_target_crs"] = initial_bounds
            _report(progress_cb, 0.15, "Warping to custom size {}x{}...".format(custom_width, custom_height))
            ds = raster_io.warp_dem(dem_path, resolved_epsg, target_width=custom_width, target_height=custom_height,
                                     resample_alg=resample_alg, output_bounds=initial_bounds)
        return ds, crop_info

    # resolution_mode in ('native', 'snap')
    _report(progress_cb, 0.10, "Reprojecting/resampling DEM (EPSG:{})...".format(resolved_epsg))
    ds = raster_io.warp_dem(dem_path, resolved_epsg, resample_alg=resample_alg, output_bounds=initial_bounds)
    crop_info["applied_bounds_target_crs"] = initial_bounds

    need_square = (resolution_mode == "snap") or (crop_mode == "centered_square")
    if not need_square:
        return ds, crop_info

    if crop_mode == "centered_square" or (resolution_mode == "snap" and square_strategy == "crop"):
        bounds, px_x, px_y = raster_io.get_bounds_and_pixel_size(ds)
        sq_bounds, side_px = raster_io.centered_square_bounds(bounds, ds.RasterXSize, ds.RasterYSize, px_x, px_y)
        target_side = nearest_valid_size(side_px) if resolution_mode == "snap" else side_px
        _report(progress_cb, 0.20, "Cropping to centered {0}x{0} square...".format(target_side))
        ds = raster_io.warp_dem(dem_path, resolved_epsg, target_width=target_side, target_height=target_side,
                                 resample_alg=resample_alg, output_bounds=sq_bounds)
        crop_info["applied_bounds_target_crs"] = sq_bounds
        crop_info["square_side_px"] = target_side
    elif resolution_mode == "snap" and square_strategy == "stretch":
        target_side = nearest_valid_size(round((ds.RasterXSize + ds.RasterYSize) / 2.0))
        _report(progress_cb, 0.20, "Stretching to square {0}x{0} (distorts aspect ratio)...".format(target_side))
        ds = raster_io.warp_dem(dem_path, resolved_epsg, target_width=target_side, target_height=target_side,
                                 resample_alg=resample_alg, output_bounds=initial_bounds)
        crop_info["square_side_px"] = target_side

    return ds, crop_info


def export_heightmap(
    dem_path: str,
    output_dir: str,
    base_name: str,
    formats: List[str] = ("png", "raw"),
    resolution_mode: str = "native",   # 'native' | 'custom' | 'snap'
    custom_width: Optional[int] = None,
    custom_height: Optional[int] = None,
    target_epsg: Optional[int] = None,
    resample_alg: str = "bilinear",
    nodata_method: str = "nearest",
    nodata_constant: Optional[float] = None,
    low_percentile: float = 0.0,
    high_percentile: float = 100.0,
    vertical_exaggeration: float = 1.0,
    tiling_enabled: bool = False,
    tile_size: int = 1009,
    overlap: int = 1,
    crop_mode: str = "none",            # 'none' | 'centered_square' | 'extent'
    crop_extent: Optional[Tuple[float, float, float, float]] = None,  # (xmin,ymin,xmax,ymax) in the SOURCE DEM's own CRS
    square_strategy: str = "crop",      # 'crop' | 'stretch' - how to force square when resolution_mode='snap' (or crop_mode='centered_square')
    progress_cb: ProgressCB = None,
) -> Dict:
    """Run the full DEM -> Unreal heightmap export and return a result
    dict (also written to <output_dir>/<base_name>_manifest.json).

    Raises on any unrecoverable error (bad path, empty DEM, etc.) - callers
    (UI / Processing algorithm) are expected to catch and surface these.
    """
    if not os.path.isdir(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    formats = [f.lower() for f in formats]
    if not formats:
        raise ValueError("At least one output format (png/raw) must be selected.")

    _report(progress_cb, 0.02, "Reading source DEM metadata...")
    src_info = raster_io.DemSourceInfo(dem_path)
    resolved_epsg = raster_io.resolve_target_epsg(src_info, target_epsg)

    ds, crop_info = _resolve_output_raster(
        dem_path=dem_path,
        src_info=src_info,
        resolved_epsg=resolved_epsg,
        resolution_mode=resolution_mode,
        custom_width=custom_width,
        custom_height=custom_height,
        resample_alg=resample_alg,
        crop_mode=crop_mode,
        crop_extent=crop_extent,
        square_strategy=square_strategy,
        progress_cb=progress_cb,
    )

    width, height = ds.RasterXSize, ds.RasterYSize
    px_x, px_y = raster_io.get_pixel_size_m(ds)
    pixel_size_m = (px_x + px_y) / 2.0  # near-enough for square-pixel reporting

    _report(progress_cb, 0.30, "Reading elevation data...")
    arr, nodata = raster_io.read_elevation_array(ds)
    ds = None  # release GDAL dataset

    _report(progress_cb, 0.40, "Filling nodata holes...")
    arr, nodata_info = raster_io.fill_nodata(
        arr, nodata, method=nodata_method, constant_value=nodata_constant
    )

    _report(progress_cb, 0.45, "Computing elevation range...")
    elev_min, elev_max = raster_io.compute_min_max(arr, low_percentile, high_percentile)
    if low_percentile > 0.0 or high_percentile < 100.0:
        np.clip(arr, elev_min, elev_max, out=arr)

    encoding = compute_encoding(elev_min, elev_max, vertical_exaggeration)
    xy_scale = compute_xy_scale(pixel_size_m)

    manifest: Dict = {
        "source_dem": os.path.abspath(dem_path),
        "target_epsg": resolved_epsg,
        "pixel_size_m": pixel_size_m,
        "width": width,
        "height": height,
        "crop": crop_info,
        "elevation_min_m": elev_min,
        "elevation_max_m": elev_max,
        "vertical_exaggeration": vertical_exaggeration,
        "nodata_handling": nodata_info,
        "unreal_import_settings": {
            "z_scale": encoding["z_scale"],
            "xy_scale": xy_scale,
            "actor_z_offset_m": encoding["actor_z_offset_m"],
            "actor_z_offset_cm": encoding["actor_z_offset_cm"],
            "note": (
                "Set Landscape import Scale X=Y={:.4f}, Z={:.4f}. After import, "
                "place the Landscape actor at world Z = {:.3f} m (the encoded "
                "midpoint, raw value 32768) so absolute elevations line up."
            ).format(xy_scale, encoding["z_scale"], encoding["actor_z_offset_m"]),
        },
        "tiles": [],
    }

    if tiling_enabled:
        snapped_tile = nearest_valid_size(tile_size)
        grid_info = compute_padded_canvas_size(width, height, snapped_tile, snapped_tile, overlap)
        _report(progress_cb, 0.55, "Padding to {}x{} tile grid ({} tiles)...".format(
            grid_info["n_cols"], grid_info["n_rows"], grid_info["n_cols"] * grid_info["n_rows"]
        ))
        padded = raster_io.pad_edge(arr, grid_info["padded_w"], grid_info["padded_h"])
        tiles = compute_tile_grid(grid_info["padded_w"], grid_info["padded_h"], snapped_tile, snapped_tile, overlap)

        manifest["tiling"] = {
            "tile_size": snapped_tile,
            "overlap": overlap,
            "n_cols": grid_info["n_cols"],
            "n_rows": grid_info["n_rows"],
        }

        total = len(tiles)
        for i, tile in enumerate(tiles):
            _report(progress_cb, 0.55 + 0.40 * (i / max(total, 1)),
                     "Writing tile {}/{}...".format(i + 1, total))
            sub = padded[tile["y_off"]:tile["y_off"] + tile["h"], tile["x_off"]:tile["x_off"] + tile["w"]]
            sub16 = raster_io.elevation_to_uint16(sub, elev_min, elev_max)
            tile_name = "{}_c{}_r{}".format(base_name, tile["col"], tile["row"])
            offset_x_m, offset_y_m = tile_world_offset_m(
                tile, grid_info["stride_x"], grid_info["stride_y"], pixel_size_m
            )
            paths = _write_formats(sub16, output_dir, tile_name, formats)
            manifest["tiles"].append(
                {
                    "name": tile_name,
                    "col": tile["col"],
                    "row": tile["row"],
                    "world_offset_x_m": offset_x_m,
                    "world_offset_y_m": offset_y_m,
                    "paths": paths,
                }
            )
    else:
        _report(progress_cb, 0.70, "Encoding to 16-bit and writing output...")
        arr16 = raster_io.elevation_to_uint16(arr, elev_min, elev_max)
        paths = _write_formats(arr16, output_dir, base_name, formats)
        manifest["tiles"].append(
            {"name": base_name, "col": 0, "row": 0, "world_offset_x_m": 0.0, "world_offset_y_m": 0.0, "paths": paths}
        )

    manifest_path = os.path.join(output_dir, "{}_manifest.json".format(base_name))
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)
    manifest["manifest_path"] = manifest_path

    _report(progress_cb, 1.0, "Done.")
    return manifest


def _write_formats(arr16: np.ndarray, output_dir: str, name: str, formats: List[str]) -> Dict[str, str]:
    paths: Dict[str, str] = {}
    if "png" in formats:
        p = os.path.join(output_dir, "{}.png".format(name))
        raster_io.write_png16(arr16, p)
        paths["png"] = p
    if "raw" in formats:
        p = os.path.join(output_dir, "{}.r16".format(name))
        raster_io.write_raw16(arr16, p)
        paths["raw"] = p
    return paths

# -*- coding: utf-8 -*-
"""
GDAL-backed raster I/O for the DEM -> Unreal heightmap pipeline.

Kept separate from core.ue_landscape_math (which has zero heavy deps) so
that the math can be unit tested without a GDAL install, and so this module
has one job: get pixels in, get pixels out, in the right CRS/units/dtype.
"""

from __future__ import annotations

import os
import struct
from typing import Optional, Tuple, Dict

import numpy as np

try:
    from osgeo import gdal, osr
    gdal.UseExceptions()
except ImportError as exc:  # pragma: no cover - only happens outside QGIS
    raise ImportError(
        "GDAL Python bindings (osgeo) are required. This module must be "
        "run inside a QGIS Python environment, which bundles GDAL."
    ) from exc

from .ue_landscape_math import auto_utm_epsg


class DemSourceInfo:
    """Lightweight summary of a source DEM, before any reprojection."""

    def __init__(self, path: str):
        ds = gdal.Open(path, gdal.GA_ReadOnly)
        if ds is None:
            raise RuntimeError("GDAL could not open DEM: {}".format(path))

        self.width = ds.RasterXSize
        self.height = ds.RasterYSize
        self.band_count = ds.RasterCount

        srs = osr.SpatialReference()
        wkt = ds.GetProjection()
        srs.ImportFromWkt(wkt) if wkt else None
        self.wkt = wkt
        self.is_geographic = bool(wkt) and srs.IsGeographic()
        self.epsg = None
        if wkt:
            try:
                code = srs.GetAuthorityCode(None)
                self.epsg = int(code) if code else None
            except Exception:
                self.epsg = None

        gt = ds.GetGeoTransform()
        self.geotransform = gt
        # Centroid in source CRS units, used to auto-pick a UTM zone if the
        # source is geographic (lon/lat).
        cx_px, cy_px = self.width / 2.0, self.height / 2.0
        self.center_x = gt[0] + cx_px * gt[1] + cy_px * gt[2]
        self.center_y = gt[3] + cx_px * gt[4] + cy_px * gt[5]

        band = ds.GetRasterBand(1)
        self.nodata = band.GetNoDataValue()
        ds = None  # close


def resolve_target_epsg(src_info: DemSourceInfo, requested_epsg: Optional[int]) -> int:
    """Pick the CRS to reproject into before measuring pixel size in
    meters. If the user supplied one, use it. Otherwise: if the source is
    already projected, keep it as-is (return its own EPSG). If the source
    is geographic (lon/lat, e.g. EPSG:4326), auto-pick the UTM zone
    covering the raster's centroid so pixel size can be expressed in
    meters."""
    if requested_epsg:
        return requested_epsg
    if not src_info.is_geographic:
        if src_info.epsg:
            return src_info.epsg
        raise ValueError(
            "Source DEM has a projected but unidentifiable CRS; please "
            "specify a target EPSG explicitly."
        )
    return auto_utm_epsg(lon=src_info.center_x, lat=src_info.center_y)


def warp_dem(
    path: str,
    target_epsg: int,
    pixel_size_m: Optional[float] = None,
    target_width: Optional[int] = None,
    target_height: Optional[int] = None,
    resample_alg: str = "bilinear",
    output_bounds: Optional[Tuple[float, float, float, float]] = None,
):
    """Reproject/resample the DEM into an in-memory dataset in the target
    CRS. Exactly one of (pixel_size_m) or (target_width and target_height)
    should be given to control output sizing; if neither is given, GDAL's
    native output resolution for the target CRS is used.

    output_bounds, if given, is (xmin, ymin, xmax, ymax) in the *target*
    CRS and restricts the warp to that extent (used for cropping).

    Returns the in-memory gdal.Dataset.
    """
    resamplers = {
        "nearest": gdal.GRA_NearestNeighbour,
        "bilinear": gdal.GRA_Bilinear,
        "cubic": gdal.GRA_Cubic,
        "cubicspline": gdal.GRA_CubicSpline,
    }
    alg = resamplers.get(resample_alg, gdal.GRA_Bilinear)

    warp_kwargs = dict(
        format="MEM",
        dstSRS="EPSG:{}".format(target_epsg),
        resampleAlg=alg,
        multithread=True,
    )
    if output_bounds is not None:
        warp_kwargs["outputBounds"] = output_bounds
    if target_width and target_height:
        warp_kwargs["width"] = int(target_width)
        warp_kwargs["height"] = int(target_height)
    elif pixel_size_m:
        warp_kwargs["xRes"] = pixel_size_m
        warp_kwargs["yRes"] = pixel_size_m
        warp_kwargs["targetAlignedPixels"] = False

    out_ds = gdal.Warp("", path, **warp_kwargs)
    if out_ds is None:
        raise RuntimeError("GDAL Warp failed for DEM: {}".format(path))
    return out_ds


def get_bounds_and_pixel_size(ds) -> Tuple[Tuple[float, float, float, float], float, float]:
    """Returns ((xmin, ymin, xmax, ymax), pixel_size_x, pixel_size_y) for a
    warped dataset, all in its own (target) CRS units."""
    gt = ds.GetGeoTransform()
    w, h = ds.RasterXSize, ds.RasterYSize
    xmin, px, ymax, py = gt[0], gt[1], gt[3], gt[5]
    xmax = xmin + w * px
    ymin = ymax + h * py
    bounds = (min(xmin, xmax), min(ymin, ymax), max(xmin, xmax), max(ymin, ymax))
    return bounds, abs(px), abs(py)


def centered_square_bounds(
    bounds: Tuple[float, float, float, float],
    width_px: int,
    height_px: int,
    pixel_size_x: float,
    pixel_size_y: float,
) -> Tuple[Tuple[float, float, float, float], int]:
    """Given the bounds/size of a (possibly non-square) raster, returns a
    centered square sub-bbox sized to the shorter pixel dimension, plus
    that side length in pixels. This is the crop step that guarantees a
    square output without anisotropic stretching."""
    xmin, ymin, xmax, ymax = bounds
    side_px = min(width_px, height_px)
    x_off = (width_px - side_px) // 2
    y_off = (height_px - side_px) // 2
    new_xmin = xmin + x_off * pixel_size_x
    new_xmax = new_xmin + side_px * pixel_size_x
    new_ymax = ymax - y_off * pixel_size_y
    new_ymin = new_ymax - side_px * pixel_size_y
    return (new_xmin, new_ymin, new_xmax, new_ymax), side_px


def transform_bounds_to_crs(
    bounds: Tuple[float, float, float, float],
    src_wkt_or_epsg,
    dst_epsg: int,
) -> Tuple[float, float, float, float]:
    """Reproject a bounding box, sampling all 4 corners plus edge
    midpoints (cheap insurance against curvature/rotation between CRSs)
    and taking the enclosing box of the results."""
    src_srs = osr.SpatialReference()
    if isinstance(src_wkt_or_epsg, int):
        src_srs.ImportFromEPSG(src_wkt_or_epsg)
    else:
        src_srs.ImportFromWkt(src_wkt_or_epsg)
    dst_srs = osr.SpatialReference()
    dst_srs.ImportFromEPSG(dst_epsg)
    # GDAL 3+ axis-order safety
    src_srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    dst_srs.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)

    ct = osr.CoordinateTransformation(src_srs, dst_srs)
    xmin, ymin, xmax, ymax = bounds
    xmid, ymid = (xmin + xmax) / 2.0, (ymin + ymax) / 2.0
    sample_points = [
        (xmin, ymin), (xmin, ymax), (xmax, ymin), (xmax, ymax),
        (xmid, ymin), (xmid, ymax), (xmin, ymid), (xmax, ymid),
    ]
    xs, ys = [], []
    for x, y in sample_points:
        tx, ty, _ = ct.TransformPoint(x, y)
        xs.append(tx)
        ys.append(ty)
    return (min(xs), min(ys), max(xs), max(ys))


def get_pixel_size_m(ds) -> Tuple[float, float]:
    """Pixel size (x, y) in CRS units. Caller is responsible for having
    warped into a projected (metric) CRS first."""
    gt = ds.GetGeoTransform()
    return abs(gt[1]), abs(gt[5])


def read_elevation_array(ds) -> Tuple[np.ndarray, Optional[float]]:
    """Read band 1 as float64. Returns (array, nodata_value)."""
    band = ds.GetRasterBand(1)
    nodata = band.GetNoDataValue()
    arr = band.ReadAsArray().astype(np.float64)
    return arr, nodata


def fill_nodata(
    arr: np.ndarray,
    nodata: Optional[float],
    method: str = "nearest",
    constant_value: Optional[float] = None,
) -> Tuple[np.ndarray, Dict[str, object]]:
    """Replace nodata/NaN pixels in-place (on a copy) so the heightmap has
    no holes (Unreal heightmaps don't support transparency/holes).

    method:
      'nearest'  -> nearest-valid-pixel fill via scipy if available,
                    otherwise falls back to 'constant' with a warning.
      'constant' -> fill with constant_value, or the data's own min if
                    constant_value is None.

    Returns (filled_array, info) where info reports what actually happened
    (useful for the manifest / UI warnings).
    """
    arr = arr.copy()
    mask = np.zeros(arr.shape, dtype=bool)
    if nodata is not None:
        mask |= np.isclose(arr, nodata)
    mask |= ~np.isfinite(arr)

    n_holes = int(mask.sum())
    info: Dict[str, object] = {"n_nodata_pixels": n_holes, "method_used": None}

    if n_holes == 0:
        info["method_used"] = "none_needed"
        return arr, info

    valid = arr[~mask]
    if valid.size == 0:
        raise ValueError("DEM has no valid (non-nodata) pixels at all.")

    if method == "nearest":
        try:
            from scipy import ndimage  # type: ignore

            # distance_transform_edt's return_indices gives, for every
            # masked pixel, the index of the nearest unmasked pixel.
            _, indices = ndimage.distance_transform_edt(
                mask, return_distances=True, return_indices=True
            )
            arr = arr[tuple(indices)]
            info["method_used"] = "nearest_scipy"
        except ImportError:
            fill_val = constant_value if constant_value is not None else float(valid.min())
            arr[mask] = fill_val
            info["method_used"] = "constant_fallback_no_scipy"
            info["fill_value"] = fill_val
    else:
        fill_val = constant_value if constant_value is not None else float(valid.min())
        arr[mask] = fill_val
        info["method_used"] = "constant"
        info["fill_value"] = fill_val

    return arr, info


def compute_min_max(
    arr: np.ndarray,
    low_percentile: float = 0.0,
    high_percentile: float = 100.0,
) -> Tuple[float, float]:
    """Elevation min/max, optionally clipping outlier percentiles (e.g. to
    ignore a handful of erroneous spike pixels). Defaults to the true
    min/max (no clipping)."""
    if low_percentile <= 0.0 and high_percentile >= 100.0:
        return float(arr.min()), float(arr.max())
    lo = float(np.percentile(arr, low_percentile))
    hi = float(np.percentile(arr, high_percentile))
    if hi <= lo:
        raise ValueError("Percentile clipping produced an empty range; widen the percentiles.")
    return lo, hi


def elevation_to_uint16(arr: np.ndarray, elev_min: float, elev_max: float) -> np.ndarray:
    """Linearly stretch elevation values to the full uint16 range,
    clipping any values outside [elev_min, elev_max] (e.g. from percentile
    clipping) to the valid bounds."""
    scale = 65535.0 / (elev_max - elev_min)
    out = (arr - elev_min) * scale
    np.clip(out, 0, 65535, out=out)
    return np.round(out).astype(np.uint16)


def pad_edge(arr: np.ndarray, target_w: int, target_h: int) -> np.ndarray:
    """Edge-replicate pad a 2D array (rows, cols) up to target_h x
    target_w, padding only on the bottom/right so tile col/row 0 stays at
    the original origin."""
    h, w = arr.shape
    pad_bottom = max(0, target_h - h)
    pad_right = max(0, target_w - w)
    if pad_bottom == 0 and pad_right == 0:
        return arr
    return np.pad(arr, ((0, pad_bottom), (0, pad_right)), mode="edge")


def write_png16(arr_uint16: np.ndarray, out_path: str) -> None:
    """Write a single-band 16-bit grayscale PNG (the format Unreal's
    Landscape importer reads natively)."""
    h, w = arr_uint16.shape
    mem_drv = gdal.GetDriverByName("MEM")
    mem_ds = mem_drv.Create("", w, h, 1, gdal.GDT_UInt16)
    mem_ds.GetRasterBand(1).WriteArray(arr_uint16)

    png_drv = gdal.GetDriverByName("PNG")
    prior = gdal.GetConfigOption("GDAL_PAM_ENABLED")
    gdal.SetConfigOption("GDAL_PAM_ENABLED", "NO")
    try:
        out_ds = png_drv.CreateCopy(out_path, mem_ds, strict=0)
        out_ds = None
    finally:
        gdal.SetConfigOption("GDAL_PAM_ENABLED", prior)
    mem_ds = None

    # CreateCopy can still leave a stray sidecar; clean up defensively.
    for suffix in (".aux.xml", ".wld"):
        sidecar = out_path + suffix
        if os.path.exists(sidecar):
            try:
                os.remove(sidecar)
            except OSError:
                pass


def write_raw16(arr_uint16: np.ndarray, out_path: str) -> None:
    """Write a headerless little-endian uint16 RAW (.r16) file, row-major
    top-to-bottom — the format World Machine / Unreal's raw heightmap
    import path expects."""
    arr_uint16.astype("<u2").tofile(out_path)

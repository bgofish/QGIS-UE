# -*- coding: utf-8 -*-
"""
DEM2UE dock widget: the GUI front-end for core.heightmap_exporter.
"""

import os
import traceback

from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox,
    QLabel, QLineEdit, QComboBox, QPushButton, QFileDialog, QCheckBox,
    QSpinBox, QDoubleSpinBox, QRadioButton, QButtonGroup, QProgressBar,
    QPlainTextEdit, QMessageBox,
)
from qgis.core import QgsProject, QgsMapLayerProxyModel, QgsMessageLog, Qgis
from qgis.gui import QgsMapLayerComboBox

from .core.ue_landscape_math import STANDARD_SIZES


class ExportWorker(QThread):
    progress = pyqtSignal(float, str)
    finished_ok = pyqtSignal(dict)
    failed = pyqtSignal(str)

    def __init__(self, kwargs):
        super().__init__()
        self._kwargs = kwargs

    def run(self):
        try:
            # Imported here (not at module load time) so that importing
            # this widget module never requires GDAL bindings to already
            # be importable at parse time on systems where that matters.
            from .core.heightmap_exporter import export_heightmap

            def cb(frac, msg):
                self.progress.emit(frac, msg)

            result = export_heightmap(progress_cb=cb, **self._kwargs)
            self.finished_ok.emit(result)
        except Exception as exc:  # noqa: BLE001
            QgsMessageLog.logMessage(traceback.format_exc(), "DEM2UE", Qgis.Critical)
            self.failed.emit(str(exc))


class Dem2UeDockWidget(QDockWidget):

    def __init__(self, iface, parent=None):
        super().__init__("DEM2UE Heightmap Exporter", parent)
        self.iface = iface
        self._worker = None
        self._build_ui()

    # ------------------------------------------------------------------
    def _build_ui(self):
        root = QWidget()
        layout = QVBoxLayout(root)

        # --- Source DEM -------------------------------------------------
        src_group = QGroupBox("Source DEM")
        src_form = QFormLayout(src_group)
        self.layer_combo = QgsMapLayerComboBox()
        self.layer_combo.setFilters(QgsMapLayerProxyModel.RasterLayer)
        src_row = QHBoxLayout()
        src_row.addWidget(self.layer_combo)
        browse_dem_btn = QPushButton("From file...")
        browse_dem_btn.clicked.connect(self._browse_dem_file)
        src_row.addWidget(browse_dem_btn)
        src_form.addRow("Raster layer:", src_row)
        self._external_dem_path = None
        layout.addWidget(src_group)

        # --- Output -------------------------------------------------------
        out_group = QGroupBox("Output")
        out_form = QFormLayout(out_group)
        out_dir_row = QHBoxLayout()
        self.output_dir_edit = QLineEdit()
        out_browse_btn = QPushButton("Browse...")
        out_browse_btn.clicked.connect(self._browse_output_dir)
        out_dir_row.addWidget(self.output_dir_edit)
        out_dir_row.addWidget(out_browse_btn)
        out_form.addRow("Output folder:", out_dir_row)

        self.base_name_edit = QLineEdit("heightmap")
        out_form.addRow("Base filename:", self.base_name_edit)

        fmt_row = QHBoxLayout()
        self.chk_png = QCheckBox("PNG (16-bit)")
        self.chk_png.setChecked(True)
        self.chk_raw = QCheckBox("RAW .r16")
        self.chk_raw.setChecked(True)
        fmt_row.addWidget(self.chk_png)
        fmt_row.addWidget(self.chk_raw)
        out_form.addRow("Formats:", fmt_row)
        layout.addWidget(out_group)

        # --- Resolution -----------------------------------------------
        res_group = QGroupBox("Resolution")
        res_layout = QVBoxLayout(res_group)
        self.rb_native = QRadioButton("Native (reprojected, no resize)")
        self.rb_custom = QRadioButton("Custom size")
        self.rb_snap = QRadioButton("Snap to nearest valid Unreal size")
        self.rb_native.setChecked(True)
        self.res_button_group = QButtonGroup(self)
        for rb in (self.rb_native, self.rb_custom, self.rb_snap):
            self.res_button_group.addButton(rb)
            res_layout.addWidget(rb)
            rb.toggled.connect(self._update_resolution_visibility)

        self.custom_row_widget = QWidget()
        custom_row = QHBoxLayout(self.custom_row_widget)
        custom_row.setContentsMargins(20, 0, 0, 0)
        custom_row.addWidget(QLabel("Width:"))
        self.custom_w = QSpinBox()
        self.custom_w.setRange(2, 16384)
        self.custom_w.setValue(2017)
        custom_row.addWidget(self.custom_w)
        custom_row.addWidget(QLabel("Height:"))
        self.custom_h = QSpinBox()
        self.custom_h.setRange(2, 16384)
        self.custom_h.setValue(2017)
        custom_row.addWidget(self.custom_h)
        res_layout.addWidget(self.custom_row_widget)

        self.snap_row_widget = QWidget()
        snap_row = QHBoxLayout(self.snap_row_widget)
        snap_row.setContentsMargins(20, 0, 0, 0)
        snap_row.addWidget(QLabel("Force square via:"))
        self.square_strategy_combo = QComboBox()
        self.square_strategy_combo.addItem("Crop (recommended - no distortion)", "crop")
        self.square_strategy_combo.addItem("Stretch (distorts aspect ratio)", "stretch")
        snap_row.addWidget(self.square_strategy_combo)
        res_layout.addWidget(self.snap_row_widget)

        valid_label = QLabel("Valid Unreal sizes: " + ", ".join(str(s) for s in STANDARD_SIZES))
        valid_label.setWordWrap(True)
        valid_label.setStyleSheet("color: gray; font-size: 10px;")
        res_layout.addWidget(valid_label)
        square_note = QLabel(
            "Snap always outputs a square heightmap (Width = Height). "
            "Non-square sizes are technically valid for Unreal Landscapes too "
            "(each axis just needs its own valid size) — use Custom size if "
            "you specifically want a rectangular heightmap."
        )
        square_note.setWordWrap(True)
        square_note.setStyleSheet("color: gray; font-size: 10px;")
        res_layout.addWidget(square_note)
        layout.addWidget(res_group)
        self._update_resolution_visibility()

        # --- Crop extent --------------------------------------------------
        crop_group = QGroupBox("Crop extent (optional)")
        crop_layout = QVBoxLayout(crop_group)
        self.rb_crop_none = QRadioButton("None - use full DEM extent")
        self.rb_crop_square = QRadioButton("Centered square crop")
        self.rb_crop_extent = QRadioButton("Manual extent")
        self.rb_crop_none.setChecked(True)
        self.crop_button_group = QButtonGroup(self)
        for rb in (self.rb_crop_none, self.rb_crop_square, self.rb_crop_extent):
            self.crop_button_group.addButton(rb)
            crop_layout.addWidget(rb)
            rb.toggled.connect(self._update_crop_visibility)

        self.crop_extent_widget = QWidget()
        crop_form = QFormLayout(self.crop_extent_widget)
        crop_form.setContentsMargins(20, 0, 0, 0)
        coord_row1 = QHBoxLayout()
        self.crop_xmin = QDoubleSpinBox()
        self.crop_xmin.setRange(-1e9, 1e9)
        self.crop_xmin.setDecimals(6)
        self.crop_ymin = QDoubleSpinBox()
        self.crop_ymin.setRange(-1e9, 1e9)
        self.crop_ymin.setDecimals(6)
        coord_row1.addWidget(QLabel("X min:"))
        coord_row1.addWidget(self.crop_xmin)
        coord_row1.addWidget(QLabel("Y min:"))
        coord_row1.addWidget(self.crop_ymin)
        crop_form.addRow(coord_row1)
        coord_row2 = QHBoxLayout()
        self.crop_xmax = QDoubleSpinBox()
        self.crop_xmax.setRange(-1e9, 1e9)
        self.crop_xmax.setDecimals(6)
        self.crop_ymax = QDoubleSpinBox()
        self.crop_ymax.setRange(-1e9, 1e9)
        self.crop_ymax.setDecimals(6)
        coord_row2.addWidget(QLabel("X max:"))
        coord_row2.addWidget(self.crop_xmax)
        coord_row2.addWidget(QLabel("Y max:"))
        coord_row2.addWidget(self.crop_ymax)
        crop_form.addRow(coord_row2)
        canvas_btn = QPushButton("Fill from current map canvas extent")
        canvas_btn.clicked.connect(self._fill_extent_from_canvas)
        crop_form.addRow(canvas_btn)
        crop_note = QLabel("Coordinates are in the DEM layer's own CRS.")
        crop_note.setStyleSheet("color: gray; font-size: 10px;")
        crop_form.addRow(crop_note)
        crop_layout.addWidget(self.crop_extent_widget)
        layout.addWidget(crop_group)
        self._update_crop_visibility()

        # --- Processing options ----------------------------------------
        proc_group = QGroupBox("Processing options")
        proc_form = QFormLayout(proc_group)

        self.resample_combo = QComboBox()
        self.resample_combo.addItems(["bilinear", "nearest", "cubic", "cubicspline"])
        proc_form.addRow("Resampling:", self.resample_combo)

        self.nodata_combo = QComboBox()
        self.nodata_combo.addItems(["nearest", "constant"])
        proc_form.addRow("Nodata fill:", self.nodata_combo)
        self.nodata_const = QDoubleSpinBox()
        self.nodata_const.setRange(-20000, 20000)
        self.nodata_const.setDecimals(2)
        self.nodata_const.setSpecialValueText("(use data min)")
        self.nodata_const.setValue(-20000)
        proc_form.addRow("Constant fill value:", self.nodata_const)

        clip_row = QHBoxLayout()
        self.chk_clip = QCheckBox("Clip outlier percentiles")
        self.pct_low = QDoubleSpinBox()
        self.pct_low.setRange(0, 49)
        self.pct_low.setValue(0)
        self.pct_low.setSuffix(" %")
        self.pct_high = QDoubleSpinBox()
        self.pct_high.setRange(51, 100)
        self.pct_high.setValue(100)
        self.pct_high.setSuffix(" %")
        clip_row.addWidget(self.chk_clip)
        clip_row.addWidget(self.pct_low)
        clip_row.addWidget(self.pct_high)
        proc_form.addRow("Outliers:", clip_row)

        self.exaggeration = QDoubleSpinBox()
        self.exaggeration.setRange(0.01, 100.0)
        self.exaggeration.setDecimals(2)
        self.exaggeration.setValue(1.0)
        proc_form.addRow("Vertical exaggeration:", self.exaggeration)

        self.epsg_override = QLineEdit()
        self.epsg_override.setPlaceholderText("auto (UTM zone for geographic DEMs)")
        proc_form.addRow("Target EPSG override:", self.epsg_override)

        layout.addWidget(proc_group)

        # --- Tiling ------------------------------------------------------
        tile_group = QGroupBox("Tiling (for large terrains)")
        tile_form = QFormLayout(tile_group)
        self.chk_tiling = QCheckBox("Enable tiled export")
        tile_form.addRow(self.chk_tiling)
        self.tile_size_combo = QComboBox()
        self.tile_size_combo.addItems([str(s) for s in STANDARD_SIZES])
        self.tile_size_combo.setCurrentText("1009")
        tile_form.addRow("Tile size (per side):", self.tile_size_combo)
        self.tile_overlap = QSpinBox()
        self.tile_overlap.setRange(1, 8)
        self.tile_overlap.setValue(1)
        tile_form.addRow("Border overlap (px):", self.tile_overlap)
        layout.addWidget(tile_group)

        # --- Run ----------------------------------------------------------
        self.run_btn = QPushButton("Export Heightmap")
        self.run_btn.clicked.connect(self._on_run_clicked)
        layout.addWidget(self.run_btn)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        layout.addWidget(self.progress_bar)

        self.summary_box = QPlainTextEdit()
        self.summary_box.setReadOnly(True)
        self.summary_box.setMinimumHeight(140)
        layout.addWidget(self.summary_box)

        layout.addStretch()
        root.setLayout(layout)

        scroll_container = QWidget()
        outer = QVBoxLayout(scroll_container)
        outer.addWidget(root)
        self.setWidget(root)

    # ------------------------------------------------------------------
    def _update_resolution_visibility(self):
        self.custom_row_widget.setVisible(self.rb_custom.isChecked())
        self.snap_row_widget.setVisible(self.rb_snap.isChecked())

    def _update_crop_visibility(self):
        self.crop_extent_widget.setVisible(self.rb_crop_extent.isChecked())

    def _current_dem_crs(self):
        if not self._external_dem_path:
            layer = self.layer_combo.currentLayer()
            if layer is not None:
                return layer.crs()
        path = self._current_dem_path()
        if path:
            from qgis.core import QgsRasterLayer
            tmp = QgsRasterLayer(path, "dem2ue_tmp")
            if tmp.isValid():
                return tmp.crs()
        return None

    def _fill_extent_from_canvas(self):
        from qgis.core import QgsCoordinateTransform, QgsProject
        dem_crs = self._current_dem_crs()
        if dem_crs is None or not dem_crs.isValid():
            QMessageBox.warning(self, "DEM2UE", "Select a valid DEM first so its CRS can be determined.")
            return
        canvas = self.iface.mapCanvas()
        canvas_extent = canvas.extent()
        canvas_crs = canvas.mapSettings().destinationCrs()
        if canvas_crs != dem_crs:
            transform = QgsCoordinateTransform(canvas_crs, dem_crs, QgsProject.instance())
            try:
                canvas_extent = transform.transformBoundingBox(canvas_extent)
            except Exception as exc:  # noqa: BLE001
                QMessageBox.warning(self, "DEM2UE", "Could not transform canvas extent: {}".format(exc))
                return
        self.crop_xmin.setValue(canvas_extent.xMinimum())
        self.crop_ymin.setValue(canvas_extent.yMinimum())
        self.crop_xmax.setValue(canvas_extent.xMaximum())
        self.crop_ymax.setValue(canvas_extent.yMaximum())

    # ------------------------------------------------------------------
    def _browse_dem_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select DEM raster", "", "Raster files (*.tif *.tiff *.asc *.img *.vrt *.dem);;All files (*.*)"
        )
        if path:
            self._external_dem_path = path
            self.layer_combo.setEnabled(False)
            self.summary_box.appendPlainText("Using DEM file: {}".format(path))

    def _browse_output_dir(self):
        path = QFileDialog.getExistingDirectory(self, "Select output folder")
        if path:
            self.output_dir_edit.setText(path)

    def _current_dem_path(self):
        if self._external_dem_path:
            return self._external_dem_path
        layer = self.layer_combo.currentLayer()
        if layer is None:
            return None
        return layer.source().split("|")[0]

    # ------------------------------------------------------------------
    def _on_run_clicked(self):
        dem_path = self._current_dem_path()
        if not dem_path or not os.path.exists(dem_path):
            QMessageBox.warning(self, "DEM2UE", "Please select a valid DEM raster layer or file.")
            return
        out_dir = self.output_dir_edit.text().strip()
        if not out_dir:
            QMessageBox.warning(self, "DEM2UE", "Please choose an output folder.")
            return
        formats = []
        if self.chk_png.isChecked():
            formats.append("png")
        if self.chk_raw.isChecked():
            formats.append("raw")
        if not formats:
            QMessageBox.warning(self, "DEM2UE", "Select at least one output format.")
            return

        resolution_mode = "native"
        if self.rb_custom.isChecked():
            resolution_mode = "custom"
        elif self.rb_snap.isChecked():
            resolution_mode = "snap"

        crop_mode = "none"
        crop_extent = None
        if self.rb_crop_square.isChecked():
            crop_mode = "centered_square"
        elif self.rb_crop_extent.isChecked():
            crop_mode = "extent"
            xmin, ymin, xmax, ymax = (
                self.crop_xmin.value(), self.crop_ymin.value(),
                self.crop_xmax.value(), self.crop_ymax.value(),
            )
            if xmax <= xmin or ymax <= ymin:
                QMessageBox.warning(self, "DEM2UE", "Crop extent is invalid (max must exceed min).")
                return
            crop_extent = (xmin, ymin, xmax, ymax)

        square_strategy = self.square_strategy_combo.currentData()

        target_epsg = None
        epsg_text = self.epsg_override.text().strip()
        if epsg_text:
            try:
                target_epsg = int(epsg_text)
            except ValueError:
                QMessageBox.warning(self, "DEM2UE", "EPSG override must be an integer code.")
                return

        nodata_constant = None
        if self.nodata_const.value() != self.nodata_const.minimum():
            nodata_constant = self.nodata_const.value()

        low_pct = self.pct_low.value() if self.chk_clip.isChecked() else 0.0
        high_pct = self.pct_high.value() if self.chk_clip.isChecked() else 100.0

        kwargs = dict(
            dem_path=dem_path,
            output_dir=out_dir,
            base_name=self.base_name_edit.text().strip() or "heightmap",
            formats=formats,
            resolution_mode=resolution_mode,
            custom_width=self.custom_w.value(),
            custom_height=self.custom_h.value(),
            target_epsg=target_epsg,
            resample_alg=self.resample_combo.currentText(),
            nodata_method=self.nodata_combo.currentText(),
            nodata_constant=nodata_constant,
            low_percentile=low_pct,
            high_percentile=high_pct,
            vertical_exaggeration=self.exaggeration.value(),
            tiling_enabled=self.chk_tiling.isChecked(),
            tile_size=int(self.tile_size_combo.currentText()),
            overlap=self.tile_overlap.value(),
            crop_mode=crop_mode,
            crop_extent=crop_extent,
            square_strategy=square_strategy,
        )

        self.run_btn.setEnabled(False)
        self.summary_box.clear()
        self.progress_bar.setValue(0)

        self._worker = ExportWorker(kwargs)
        self._worker.progress.connect(self._on_progress)
        self._worker.finished_ok.connect(self._on_finished)
        self._worker.failed.connect(self._on_failed)
        self._worker.start()

    def _on_progress(self, frac, msg):
        self.progress_bar.setValue(int(frac * 100))
        self.summary_box.appendPlainText(msg)

    def _on_finished(self, result):
        self.run_btn.setEnabled(True)
        ui = result["unreal_import_settings"]
        lines = [
            "",
            "=== Export complete ===",
            "Manifest: {}".format(result.get("manifest_path", "")),
            "Tiles written: {}".format(len(result.get("tiles", []))),
            "",
            "--- Unreal Landscape import settings ---",
            "Scale X = Y = {:.4f}".format(ui["xy_scale"]),
            "Scale Z      = {:.4f}".format(ui["z_scale"]),
            "Place actor at world Z = {:.3f} m".format(ui["actor_z_offset_m"]),
        ]
        for t in result.get("tiles", []):
            lines.append("  tile {}: offset ({:.1f} m, {:.1f} m) -> {}".format(
                t["name"], t["world_offset_x_m"], t["world_offset_y_m"],
                ", ".join(t["paths"].values())
            ))
        self.summary_box.appendPlainText("\n".join(lines))
        self.iface.messageBar().pushSuccess("DEM2UE", "Heightmap export finished.")

    def _on_failed(self, msg):
        self.run_btn.setEnabled(True)
        self.summary_box.appendPlainText("\nERROR: {}".format(msg))
        QMessageBox.critical(self, "DEM2UE - Export failed", msg)

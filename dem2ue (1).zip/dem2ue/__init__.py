# -*- coding: utf-8 -*-
"""
DEM2UE - Export 16-bit greyscale Unreal Engine Landscape heightmaps from
DEMs, directly from QGIS.
"""


def classFactory(iface):
    from .dem2ue_plugin import Dem2UePlugin
    return Dem2UePlugin(iface)

# -*- coding: utf-8 -*-
import os

from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon


class Dem2UeProvider(QgsProcessingProvider):

    def id(self):
        return "dem2ue"

    def name(self):
        return "DEM2UE"

    def icon(self):
        icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "icon.png")
        return QIcon(icon_path)

    def loadAlgorithms(self):
        from .export_heightmap_algorithm import ExportHeightmapAlgorithm
        self.addAlgorithm(ExportHeightmapAlgorithm())

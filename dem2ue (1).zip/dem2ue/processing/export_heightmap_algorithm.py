# -*- coding: utf-8 -*-

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterString,
    QgsProcessingParameterEnum,
    QgsProcessingParameterNumber,
    QgsProcessingParameterCrs,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterExtent,
    QgsProcessingOutputString,
    QgsProcessingException,
)

from ..core.ue_landscape_math import STANDARD_SIZES


class ExportHeightmapAlgorithm(QgsProcessingAlgorithm):

    INPUT = "INPUT"
    OUTPUT_DIR = "OUTPUT_DIR"
    BASE_NAME = "BASE_NAME"
    FORMATS = "FORMATS"
    RESOLUTION_MODE = "RESOLUTION_MODE"
    CUSTOM_WIDTH = "CUSTOM_WIDTH"   # kept for API back-compat; UI uses CUSTOM_SIZE
    CUSTOM_HEIGHT = "CUSTOM_HEIGHT"
    CUSTOM_SIZE = "CUSTOM_SIZE"
    TARGET_CRS = "TARGET_CRS"
    RESAMPLE_ALG = "RESAMPLE_ALG"
    NODATA_METHOD = "NODATA_METHOD"
    NODATA_CONSTANT = "NODATA_CONSTANT"
    CLIP_LOW_PCT = "CLIP_LOW_PCT"
    CLIP_HIGH_PCT = "CLIP_HIGH_PCT"
    VERTICAL_EXAGGERATION = "VERTICAL_EXAGGERATION"
    TILING_ENABLED = "TILING_ENABLED"
    TILE_SIZE = "TILE_SIZE"
    TILE_OVERLAP = "TILE_OVERLAP"
    CROP_MODE = "CROP_MODE"
    CROP_EXTENT = "CROP_EXTENT"
    SQUARE_STRATEGY = "SQUARE_STRATEGY"
    MANIFEST = "MANIFEST"

    FORMAT_OPTIONS = ["PNG (16-bit)", "RAW .r16"]
    RESOLUTION_OPTIONS = ["Native (reprojected, no resize)", "Custom size", "Snap to nearest valid Unreal size"]
    RESAMPLE_OPTIONS = ["bilinear", "nearest", "cubic", "cubicspline"]
    NODATA_OPTIONS = ["nearest", "constant"]
    TILE_SIZE_OPTIONS = [str(s) for s in STANDARD_SIZES]
    CUSTOM_SIZE_OPTIONS = ["{0} × {0}".format(s) for s in STANDARD_SIZES]
    CROP_MODE_OPTIONS = ["None - use full DEM extent", "Centered square crop", "Manual extent"]
    SQUARE_STRATEGY_OPTIONS = ["Crop (recommended - no distortion)", "Stretch (distorts aspect ratio)"]

    def createInstance(self):
        return ExportHeightmapAlgorithm()

    def name(self):
        return "export_unreal_heightmap"

    def displayName(self):
        return "Export Unreal Engine Heightmap from DEM"

    def group(self):
        return "DEM2UE"

    def groupId(self):
        return "dem2ue"

    def shortHelpString(self):
        return (
            "Exports a DEM as a 16-bit greyscale Unreal Engine Landscape heightmap "
            "(PNG and/or headerless RAW .r16), with correct Z-scale/XY-scale/actor-offset "
            "math, automatic UTM reprojection for geographic DEMs, nodata filling, "
            "snapping to Epic's valid Landscape resolutions, optional cropping (centered "
            "square or a manual extent), and optional seamless tiling for large terrains "
            "(shared global elevation range across all tiles). Snap mode and the centered "
            "square crop always produce square output by cropping rather than anisotropic "
            "stretching, unless 'Stretch' is explicitly chosen."
        )

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT, "Input DEM"))
        self.addParameter(QgsProcessingParameterFolderDestination(self.OUTPUT_DIR, "Output folder"))
        self.addParameter(QgsProcessingParameterString(self.BASE_NAME, "Base filename", defaultValue="heightmap"))
        self.addParameter(QgsProcessingParameterEnum(
            self.FORMATS, "Output formats", options=self.FORMAT_OPTIONS, allowMultiple=True, defaultValue=[0, 1]
        ))
        self.addParameter(QgsProcessingParameterEnum(
            self.RESOLUTION_MODE, "Resolution mode", options=self.RESOLUTION_OPTIONS, defaultValue=0
        ))
        self.addParameter(QgsProcessingParameterEnum(
            self.SQUARE_STRATEGY,
            "When square output is required (Snap mode, or Centered square crop), force it via",
            options=self.SQUARE_STRATEGY_OPTIONS, defaultValue=0
        ))
        self.addParameter(QgsProcessingParameterEnum(
            self.CUSTOM_SIZE, "Custom size (square, used when Resolution mode = Custom)",
            options=self.CUSTOM_SIZE_OPTIONS,
            defaultValue=self.CUSTOM_SIZE_OPTIONS.index("2017 × 2017"),
            optional=True,
        ))
        self.addParameter(QgsProcessingParameterCrs(self.TARGET_CRS, "Target CRS (blank = auto UTM)", optional=True))
        self.addParameter(QgsProcessingParameterEnum(
            self.RESAMPLE_ALG, "Resampling algorithm", options=self.RESAMPLE_OPTIONS, defaultValue=0
        ))
        self.addParameter(QgsProcessingParameterEnum(
            self.NODATA_METHOD, "Nodata fill method", options=self.NODATA_OPTIONS, defaultValue=0
        ))
        p = QgsProcessingParameterNumber(self.NODATA_CONSTANT, "Constant fill value (if method=constant)",
                                          type=QgsProcessingParameterNumber.Double,
                                          optional=True)
        self.addParameter(p)
        self.addParameter(QgsProcessingParameterNumber(
            self.CLIP_LOW_PCT, "Clip low percentile", type=QgsProcessingParameterNumber.Double,
            defaultValue=0.0, minValue=0.0, maxValue=49.0
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.CLIP_HIGH_PCT, "Clip high percentile", type=QgsProcessingParameterNumber.Double,
            defaultValue=100.0, minValue=51.0, maxValue=100.0
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.VERTICAL_EXAGGERATION, "Vertical exaggeration", type=QgsProcessingParameterNumber.Double,
            defaultValue=1.0, minValue=0.01
        ))
        self.addParameter(QgsProcessingParameterBoolean(self.TILING_ENABLED, "Enable tiled export", defaultValue=False))
        self.addParameter(QgsProcessingParameterEnum(
            self.TILE_SIZE, "Tile size (per side)", options=self.TILE_SIZE_OPTIONS,
            defaultValue=self.TILE_SIZE_OPTIONS.index("1009")
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.TILE_OVERLAP, "Tile border overlap (px)", type=QgsProcessingParameterNumber.Integer,
            defaultValue=1, minValue=1, maxValue=8
        ))
        self.addParameter(QgsProcessingParameterEnum(
            self.CROP_MODE, "Crop extent", options=self.CROP_MODE_OPTIONS, defaultValue=0
        ))
        self.addParameter(QgsProcessingParameterExtent(self.CROP_EXTENT, "Manual crop extent", optional=True))
        self.addOutput(QgsProcessingOutputString(self.MANIFEST, "Manifest JSON path"))

    def processAlgorithm(self, parameters, context, feedback):
        from ..core.heightmap_exporter import export_heightmap

        layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        if layer is None:
            raise QgsProcessingException("Invalid input DEM layer.")
        dem_path = layer.source().split("|")[0]

        output_dir = self.parameterAsString(parameters, self.OUTPUT_DIR, context)
        base_name = self.parameterAsString(parameters, self.BASE_NAME, context) or "heightmap"

        fmt_indices = self.parameterAsEnums(parameters, self.FORMATS, context)
        formats = []
        if 0 in fmt_indices:
            formats.append("png")
        if 1 in fmt_indices:
            formats.append("raw")
        if not formats:
            raise QgsProcessingException("Select at least one output format.")

        resolution_mode_idx = self.parameterAsEnum(parameters, self.RESOLUTION_MODE, context)
        resolution_mode = ["native", "custom", "snap"][resolution_mode_idx]

        custom_side = None
        if resolution_mode == "custom":
            idx = self.parameterAsEnum(parameters, self.CUSTOM_SIZE, context)
            custom_side = STANDARD_SIZES[idx]
        custom_width = custom_side
        custom_height = custom_side

        target_epsg = None
        crs = self.parameterAsCrs(parameters, self.TARGET_CRS, context)
        if crs is not None and crs.isValid():
            authid = crs.authid()
            if authid.startswith("EPSG:"):
                target_epsg = int(authid.split(":")[1])

        resample_alg = self.RESAMPLE_OPTIONS[self.parameterAsEnum(parameters, self.RESAMPLE_ALG, context)]
        nodata_method = self.NODATA_OPTIONS[self.parameterAsEnum(parameters, self.NODATA_METHOD, context)]
        nodata_constant = (
            self.parameterAsDouble(parameters, self.NODATA_CONSTANT, context)
            if parameters.get(self.NODATA_CONSTANT) is not None else None
        )
        low_pct = self.parameterAsDouble(parameters, self.CLIP_LOW_PCT, context)
        high_pct = self.parameterAsDouble(parameters, self.CLIP_HIGH_PCT, context)
        vertical_exaggeration = self.parameterAsDouble(parameters, self.VERTICAL_EXAGGERATION, context)
        tiling_enabled = self.parameterAsBoolean(parameters, self.TILING_ENABLED, context)
        tile_size = int(self.TILE_SIZE_OPTIONS[self.parameterAsEnum(parameters, self.TILE_SIZE, context)])
        tile_overlap = self.parameterAsInt(parameters, self.TILE_OVERLAP, context)

        square_strategy = ["crop", "stretch"][self.parameterAsEnum(parameters, self.SQUARE_STRATEGY, context)]
        crop_mode_idx = self.parameterAsEnum(parameters, self.CROP_MODE, context)
        crop_mode = ["none", "centered_square", "extent"][crop_mode_idx]
        crop_extent = None
        if crop_mode == "extent":
            if parameters.get(self.CROP_EXTENT) is None:
                raise QgsProcessingException("Manual crop extent is required when Crop extent = 'Manual extent'.")
            # Request the extent already reprojected into the DEM's own CRS,
            # since that's what export_heightmap's crop_extent expects.
            rect = self.parameterAsExtent(parameters, self.CROP_EXTENT, context, crs=layer.crs())
            crop_extent = (rect.xMinimum(), rect.yMinimum(), rect.xMaximum(), rect.yMaximum())

        def cb(frac, msg):
            feedback.setProgress(int(frac * 100))
            feedback.pushInfo(msg)

        result = export_heightmap(
            dem_path=dem_path,
            output_dir=output_dir,
            base_name=base_name,
            formats=formats,
            resolution_mode=resolution_mode,
            custom_width=custom_width,
            custom_height=custom_height,
            target_epsg=target_epsg,
            resample_alg=resample_alg,
            nodata_method=nodata_method,
            nodata_constant=nodata_constant,
            low_percentile=low_pct,
            high_percentile=high_pct,
            vertical_exaggeration=vertical_exaggeration,
            tiling_enabled=tiling_enabled,
            tile_size=tile_size,
            overlap=tile_overlap,
            crop_mode=crop_mode,
            crop_extent=crop_extent,
            square_strategy=square_strategy,
            progress_cb=cb,
        )

        ui = result["unreal_import_settings"]
        feedback.pushInfo("")
        feedback.pushInfo("--- Unreal Landscape import settings ---")
        feedback.pushInfo("Scale X = Y = {:.4f}".format(ui["xy_scale"]))
        feedback.pushInfo("Scale Z      = {:.4f}".format(ui["z_scale"]))
        feedback.pushInfo("Place actor at world Z = {:.3f} m".format(ui["actor_z_offset_m"]))

        return {self.MANIFEST: result["manifest_path"], self.OUTPUT_DIR: output_dir}

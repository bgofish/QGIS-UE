# -*- coding: utf-8 -*-
import os

from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsApplication


class Dem2UePlugin:

    def __init__(self, iface):
        self.iface = iface
        self.dock_widget = None
        self.action = None
        self.provider = None
        self.plugin_dir = os.path.dirname(__file__)

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        self.action = QAction(QIcon(icon_path), "DEM2UE Heightmap Exporter", self.iface.mainWindow())
        self.action.triggered.connect(self.toggle_dock)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("DEM2UE", self.action)

        # Processing provider (Toolbox integration)
        from .processing.dem2ue_provider import Dem2UeProvider
        self.provider = Dem2UeProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def toggle_dock(self):
        if self.dock_widget is None:
            from .dem2ue_dockwidget import Dem2UeDockWidget
            self.dock_widget = Dem2UeDockWidget(self.iface, self.iface.mainWindow())
            self.iface.addDockWidget(0x2, self.dock_widget)  # Qt.RightDockWidgetArea
        self.dock_widget.setVisible(not self.dock_widget.isVisible())

    def unload(self):
        if self.action:
            self.iface.removePluginMenu("DEM2UE", self.action)
            self.iface.removeToolBarIcon(self.action)
        if self.dock_widget:
            self.iface.removeDockWidget(self.dock_widget)
            self.dock_widget.deleteLater()
            self.dock_widget = None
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None

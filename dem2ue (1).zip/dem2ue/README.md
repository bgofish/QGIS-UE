# DEM2UE Heightmap Exporter (QGIS plugin)

Exports DEM elevation rasters as 16-bit greyscale Unreal Engine Landscape
heightmaps (PNG and/or headerless RAW `.r16`), with the exact import-side
math worked out for you (Z Scale, X/Y Scale, actor placement), and optional
seamless tiling for large terrains.

## Install

1. Zip the `dem2ue` folder (or use the zip you were given) so the top level
   of the archive is the `dem2ue/` folder itself.
2. QGIS → Plugins → Manage and Install Plugins → Install from ZIP → select
   the zip → Install.
3. Enable "DEM2UE Heightmap Exporter" in the plugin list if it isn't
   already active.

You'll get a toolbar/menu icon that opens a dock panel, **and** a
"DEM2UE" group in the Processing Toolbox (so you can run it from a model,
batch over many DEMs, or call it from the Python console).

### Dependencies
Everything needed (GDAL, NumPy) ships with QGIS itself — no extra installs
required. If `scipy` happens to be present in your QGIS Python environment,
nodata holes get filled via true nearest-valid-pixel interpolation;
otherwise the plugin falls back to a constant fill (using the DEM's own
minimum elevation by default) and tells you so in the output log.

## Using the dock panel

1. Pick a loaded raster layer (or "From file..." to browse without
   loading it into the project).
2. Choose an output folder and base filename.
3. Pick formats — PNG, RAW, or both.
4. Resolution:
   - **Native**: reprojects to a metric CRS (auto-UTM if your DEM is in
     lat/lon) without forcing a pixel count. Width and height follow the
     DEM's natural (possibly non-square) aspect ratio.
   - **Custom size**: exact width/height you specify — can be non-square
     if you want a rectangular heightmap (Unreal does support rectangular
     Landscapes; each axis just needs to independently satisfy the valid-
     size formula).
   - **Snap to nearest valid Unreal size**: rounds to the nearest of Epic's
     standard Landscape resolutions (127, 253, 505, 1009, 2017, 4033,
     8129). **Snap always produces a square output (Width = Height)** —
     if your DEM's native aspect ratio isn't square, the longer axis is
     cropped down to match the shorter one *before* snapping, by default.
     This avoids the alternative (anisotropically stretching one axis more
     than the other), which would distort real-world slopes and terrain
     shape. If you genuinely want stretch-to-square instead of crop, switch
     "Force square via" to Stretch.
5. Crop extent (optional, independent of the Resolution setting above):
   - **None**: use the full DEM extent (default).
   - **Centered square crop**: trims the longer axis symmetrically so the
     processed area is square at native resolution, before any further
     resizing. Useful on its own (e.g. with Native or Custom resolution)
     or stacked with Snap.
   - **Manual extent**: type in a bounding box (in the DEM layer's own
     CRS), or click "Fill from current map canvas extent" to grab whatever
     you're currently looking at in the QGIS map view. Handy for pulling
     just a sub-region out of a much larger DEM before exporting.
6. Processing options: resampling algorithm, nodata fill method, optional
   outlier percentile clipping (for DEMs with a handful of garbage spike
   pixels), vertical exaggeration, and an optional manual EPSG override if
   you don't want the auto-UTM pick.
7. Tiling: enable for large terrains. Pick a per-tile size from the valid
   list; tiles share a 1px border with their neighbors so adjacent
   Landscape Streaming Proxies line up with no seam. The elevation
   min/max used for 16-bit encoding is computed once across the *entire*
   DEM (or cropped area) and applied identically to every tile — this is
   what keeps tile edges height-consistent.
8. Click **Export Heightmap**. It runs on a background thread so QGIS
   stays responsive; progress and a settings summary appear below.

Each export writes a `<basename>_manifest.json` alongside the heightmap(s)
with every number you need on the Unreal side.

## On the Unreal Engine side

Unreal's Landscape importer encodes a 16-bit heightmap value as a height in
the range -256.0 to +255.992, then multiplies by the **Z Scale** you enter
at import to get centimeters (Unreal's heights are in cm). The plugin
already worked out, from your DEM's real elevation range, the exact Z Scale
that reproduces true-to-life relief:

- **Scale X = Y**: set both to the `xy_scale` value in the manifest (this
  makes each heightmap pixel correspond to its real-world ground distance).
- **Scale Z**: set to the manifest's `z_scale`.
- After import, move the Landscape actor to **world Z = `actor_z_offset_m`**
  (meters). The heightmap's raw value 32768 always decodes to local height
  0, which corresponds to the midpoint of your DEM's elevation range —
  placing the actor there puts your terrain at the correct absolute
  elevation.
- `vertical_exaggeration` (default 1.0) scales the apparent relief if you
  want a more dramatic or flatter look while keeping the math consistent.

### Single heightmap
Landscape Mode → Manage → Import from File → pick the PNG or `.r16`, plug
in the Scale X/Y/Z and the resolution should auto-detect (or match the
manifest's width/height if asked).

### Tiled terrains
Each `<basename>_c{col}_r{row}` file is one Landscape Streaming Proxy.
Import each tile separately at the same Scale X/Y/Z (they share encoding,
so the scale is identical across all tiles), then position each one at the
manifest's `world_offset_x_m` / `world_offset_y_m` relative to tile
(0,0) — with World Partition (UE5) this is mostly automatic once Landscapes
are placed correctly relative to each other; with World Composition (UE4)
you'll set this in the Levels/World Composition browser.

## Notes & limitations

- 16-bit PNGs use single-channel grayscale (`colortype 0`, `bitdepth 16`)
  — exactly what Unreal's importer expects.
- `.r16` files are headerless little-endian uint16, row-major from the top
  — the same convention World Machine and Unreal's raw import path use.
- If your DEM's CRS is geographic (lat/lon), the plugin auto-picks the UTM
  zone covering its centroid so pixel size can be measured in meters; you
  can override this with an explicit target EPSG if you need a specific
  projected CRS instead (e.g. to match an existing UTM-based pipeline).
- Outlier percentile clipping is off by default (full true min/max is
  used); turn it on only if you know your DEM has a few garbage spikes —
  clipped values are hard-clamped to the percentile bounds before encoding,
  not discarded.
